package com.impulse.alert

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var toggle: Button
    private val h = Handler(Looper.getMainLooper())
    private var n = 0
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            if (n++ % 5 == 0) refreshStats()
            h.postDelayed(this, 1000)
        }
    }

    private fun journalFile() = File(filesDir, "signals.csv")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        stats = TextView(this).apply { textSize = 14f; setPadding(0, 32, 0, 32) }
        toggle = Button(this)
        val battery = Button(this).apply { text = "Вимкнути оптимізацію батареї (важливо)" }
        val share = Button(this).apply { text = "Експорт журналу (CSV)" }
        val clear = Button(this).apply { text = "Очистити журнал" }

        root.addView(TextView(this).apply {
            text = "Impulse Alert\nBinance Futures • сигнал на вхід"
            textSize = 22f; gravity = Gravity.CENTER
        })
        root.addView(status)
        root.addView(toggle)
        root.addView(stats)
        root.addView(share)
        root.addView(clear)
        root.addView(battery)
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val prefs = getSharedPreferences("p", MODE_PRIVATE)

        toggle.setOnClickListener {
            if (MonitorService.running) {
                stopService(Intent(this, MonitorService::class.java))
                prefs.edit().putBoolean("on", false).apply()
            } else {
                startForegroundService(Intent(this, MonitorService::class.java))
                prefs.edit().putBoolean("on", true).apply()
            }
            refresh()
        }

        battery.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        share.setOnClickListener {
            val f = journalFile()
            if (!f.exists()) {
                Toast.makeText(this, "Журнал порожній", Toast.LENGTH_SHORT).show()
            } else {
                val uri = FileProvider.getUriForFile(this, "com.impulse.alert.files", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Експорт журналу"))
            }
        }

        clear.setOnClickListener {
            journalFile().delete()
            refreshStats()
        }

        if (prefs.getBoolean("on", false) && !MonitorService.running)
            startForegroundService(Intent(this, MonitorService::class.java))
    }

    override fun onResume() { super.onResume(); n = 0; h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun refresh() {
        toggle.text = if (MonitorService.running) "ЗУПИНИТИ" else "ЗАПУСТИТИ"
        status.text = "Статус: ${MonitorService.status}"
    }

    private fun refreshStats() {
        stats.text = SignalJournal.statsText(journalFile()) +
            "\nВідстежується зараз: ${SignalJournal.tracking}"
    }
}
