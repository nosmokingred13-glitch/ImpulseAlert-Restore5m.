# ImpulseAlert automatic execution (guarded integration)

## Default safety behavior
- Auto-trading is OFF by default.
- Demo Futures is the default endpoint: https://demo-fapi.binance.com.
- Live mode requires a separate confirmation in the UI. Credentials are stored encrypted using Android Keystore AES/GCM.
- Configure Demo API credentials first. Never enable API withdrawal permission.
- Leverage is fixed at x10 by the execution bridge and executor.
- Margin and simultaneous-position limits use the Futures wallet balance: $1–$9.99 → $0.50 margin, 1 position; $10 → $2, 1; $20 → $4, 1; $30 → $6, 1; $40 → $8, 1; $50 → $10, 2; $100 → $13, 3; $250 → $25, 4; $500 → $40, 5; $1,000 → $80, 5; $2,500 → $200, 5; $5,000 → $400, 5; $10,000+ → $800, 5. Intermediate balances use the highest tier already reached.
- Before each entry, the app queries current open Futures positions, blocks duplicate entries for the same symbol, and refuses a new trade when the tier's open-position limit is reached. Entry executions are serialized inside the app to reduce race conditions.
- The selected margin is capped by currently available USDT and the configured margin cap (default $800). Actual order notional is approximately margin × 10 with a small fee reserve. Exchange minimum-notional or quantity violations reject the trade rather than increasing size.
- Notional is approximately margin × 10 with a small fee reserve. Exchange minNotional or quantity violations reject the trade rather than increasing size. Some pairs may not be tradable with a $1 account because of exchange minimums.
- If the order response does not confirm a fill or conditional orders are not acknowledged as active, the flow fails closed and attempts a reduce-only emergency close when appropriate.

## Integration
The existing `MonitorService.handleDetectedSignal` still confirms 15m EMA before the execution call. After confirmation it calls `executeAutoTradeIfEnabled(symbol, dir)`; the call runs off the main thread and deduplicates concurrent executions by symbol. Existing signal notification and `signals.csv` journaling remain intact. Trade events are written separately to app-private `trades.csv`.

## Binance conditional-order API
MARKET entry uses `POST /fapi/v1/order`. USDⓈ-M Futures conditional STOP_MARKET and TAKE_PROFIT_MARKET protection uses `POST /fapi/v1/algoOrder` with `algoType=CONDITIONAL`, `triggerPrice` (not `stopPrice`), `closePosition=true`, and `workingType=MARK_PRICE`. See the current official Futures API documentation before deployment.

## Important deployment checks
Do not enable live mode until the APK build passes and the complete flow has been verified on Demo Futures. Confirm that the Demo API supports conditional algo orders, check open positions/orders on restart, and reconcile actual fills/fees/PnL. If a request times out after submission, do not blindly retry: query order state first. The CSV logger currently records entry/protection and error events; realized PnL, commissions, MFE/MAE require trade/fill stream reconciliation and are not fabricated by this module.
