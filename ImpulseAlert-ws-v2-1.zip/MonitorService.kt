package com.impulse.alert

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import okhttp3.*
import org.json.JSONArray
import java.util.concurrent.TimeUnit

class MonitorService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var status = "Зупинено"
        private const val WS_URL = "wss://fstream.binance.com/ws/!miniTicker@arr"
        private const val CH_SERVICE = "service_v1"
        private const val CH_ALERT = "alerts_v1"
        private const val SERVICE_ID = 1
    }

    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var ws: WebSocket? = null
    private var generation = 0
    @Volatile private var lastMsg = 0L
    private var backoff = 2_000L
    private var wakeLock: PowerManager.WakeLock? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var hasNetwork = false
    private var msgCount = 0L

    private lateinit var journal: SignalJournal

    private val detector = ImpulseDetector { symbol, dir, move, vol, price -> notifySignal(symbol, dir, move, vol, price) }

    private val connectRunnable = Runnable { connect() }

    private val watchdog = object : Runnable {
        override fun run() {
            val silent = System.currentTimeMillis() - lastMsg
            if (hasNetwork && ws != null && silent > 20_000) {
                status = "Немає даних ${silent / 1000}с — перепідключення…"
                connect()
            }
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        journal = SignalJournal(java.io.File(filesDir, "signals.csv"))
        createChannels()
        val notif = buildServiceNotification("Запуск…")
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, SERVICE_ID, notif, type)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ImpulseAlert:ws").apply {
            setReferenceCounted(false)
            acquire()
        }

        registerNetworkCallback()
        handler.postDelayed(watchdog, 10_000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        status = "Зупинено"
        handler.removeCallbacksAndMessages(null)
        netCallback?.let {
            try { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (_: Exception) {}
        }
        generation++
        ws?.cancel()
        ws = null
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ---------- Мережа ----------

    private fun registerNetworkCallback() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                hasNetwork = true
                backoff = 2_000L
                handler.post { connect() }          // Wi-Fi <-> mobile: новий сокет
            }
            override fun onLost(network: Network) {
                hasNetwork = false
                handler.post {
                    generation++
                    ws?.cancel(); ws = null
                    handler.removeCallbacks(connectRunnable)
                    status = "Немає інтернету, чекаю мережу…"
                    updateServiceNotification()
                }
            }
        }
        netCallback = cb
        try { cm.registerDefaultNetworkCallback(cb) } catch (e: Exception) {
            hasNetwork = true; connect()
        }
    }

    // ---------- WebSocket ----------

    private fun connect() {
        handler.removeCallbacks(connectRunnable)
        val gen = ++generation
        try { ws?.cancel() } catch (_: Exception) {}
        status = "Підключення до Binance…"
        lastMsg = System.currentTimeMillis()
        ws = client.newWebSocket(Request.Builder().url(WS_URL).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) return
                detector.clear()                    // розрив у даних — стару історію не використовуємо
                backoff = 2_000L
                status = "Підключено ✓ (Binance Futures)"
                updateServiceNotification()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation) return
                val now = System.currentTimeMillis()
                lastMsg = now
                try {
                    val arr = JSONArray(text)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val s = o.getString("s")
                        if (!s.endsWith("USDT")) continue
                        val price = o.getString("c").toDouble()
                        detector.onTick(s, price, o.getString("q").toDouble(), now)
                        journal.onTick(s, price, now)
                    }
                    msgCount++
                    if (msgCount % 5 == 0L) status = "Підключено ✓ монет: ${arr.length()}"
                } catch (_: Exception) { /* ігноруємо биті кадри */ }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen == generation) scheduleReconnect("Сокет закрито")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen == generation) scheduleReconnect("Збій: ${t.javaClass.simpleName}")
            }
        })
    }

    private fun scheduleReconnect(reason: String) {
        handler.post {
            if (!running) return@post
            status = "$reason. Повтор через ${backoff / 1000}с…"
            updateServiceNotification()
            handler.removeCallbacks(connectRunnable)
            handler.postDelayed(connectRunnable, backoff)
            backoff = (backoff * 2).coerceAtMost(30_000L)
        }
    }

    // ---------- Сповіщення ----------

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Фоновий моніторинг", NotificationManager.IMPORTANCE_LOW)
        )
        val alert = NotificationChannel(CH_ALERT, "Імпульси", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 400, 150, 400)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
        }
        nm.createNotificationChannel(alert)
    }

    private fun openAppIntent() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildServiceNotification(text: String) =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Impulse Alert працює")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun updateServiceNotification() {
        try {
            getSystemService(NotificationManager::class.java)
                .notify(SERVICE_ID, buildServiceNotification(status))
        } catch (_: Exception) {}
    }

    private fun notifySignal(symbol: String, dir: String, move: Double, vol: Double, price: Double) {
        journal.add(symbol, dir, price, move, vol, System.currentTimeMillis())
        val sign = if (dir == "LONG") "+" else "-"
        val coin = symbol.removeSuffix("USDT")
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("$coin — ВХІД $dir")
            .setContentText("Старт імпульсу $sign${"%.2f".format(move)}% • обсяг x${"%.1f".format(vol)} • ціна $price")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        try {
            NotificationManagerCompat.from(this).notify(symbol.hashCode(), n)
        } catch (_: SecurityException) { /* немає дозволу на сповіщення */ }
    }
}
