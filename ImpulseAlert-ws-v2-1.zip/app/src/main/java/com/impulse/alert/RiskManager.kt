package com.impulse.alert

import java.math.BigDecimal
import java.math.RoundingMode

data class RiskLevels(val stopLoss: BigDecimal, val takeProfit: BigDecimal, val stopFraction: BigDecimal, val targetFraction: BigDecimal)
data class MarginTier(val minBalance: BigDecimal, val margin: BigDecimal, val maxPositions: Int)

class RiskManager(
    private val stopFraction: BigDecimal = BigDecimal("0.004"),
    private val targetFraction: BigDecimal = BigDecimal("0.012"),
    private val feeReserveFraction: BigDecimal = BigDecimal("0.002")
) {
    private val marginTiers = listOf(
        // At tiny balances, use $0.60 margin so x10 gives a $6 target notional.
        // If an exchange symbol requires more than $6 notional, skip it rather than overspend.
        MarginTier(BigDecimal("1"), BigDecimal("1"), 1),
        MarginTier(BigDecimal("10"), BigDecimal("2"), 1),
        MarginTier(BigDecimal("20"), BigDecimal("4"), 1),
        MarginTier(BigDecimal("30"), BigDecimal("6"), 1),
        MarginTier(BigDecimal("40"), BigDecimal("8"), 1),
        MarginTier(BigDecimal("50"), BigDecimal("8"), 2),
        MarginTier(BigDecimal("100"), BigDecimal("13"), 3),
        MarginTier(BigDecimal("250"), BigDecimal("25"), 4),
        MarginTier(BigDecimal("500"), BigDecimal("40"), 5),
        MarginTier(BigDecimal("1000"), BigDecimal("80"), 5),
        MarginTier(BigDecimal("2500"), BigDecimal("200"), 5),
        MarginTier(BigDecimal("5000"), BigDecimal("400"), 5),
        MarginTier(BigDecimal("10000"), BigDecimal("800"), 5)
    )

    init {
        require(stopFraction > BigDecimal.ZERO && stopFraction < BigDecimal("0.1"))
        require(targetFraction > BigDecimal.ZERO && targetFraction <= BigDecimal("0.1"))
        require(feeReserveFraction >= BigDecimal.ZERO && feeReserveFraction < BigDecimal("0.1"))
    }

    /** Balance tiers set both margin per trade and maximum simultaneous open positions. */
    fun marginForBalance(availableUsdt: BigDecimal): BigDecimal {
        require(availableUsdt >= BigDecimal.ONE) { "Need at least 1 USDT available to start" }
        return marginTiers.lastOrNull { availableUsdt >= it.minBalance }!!.margin
    }

    fun maxConcurrentPositions(availableUsdt: BigDecimal): Int {
        require(availableUsdt >= BigDecimal.ONE) { "Need at least 1 USDT available to start" }
        return marginTiers.lastOrNull { availableUsdt >= it.minBalance }!!.maxPositions
    }

    /** The selected tier margin is a target; never exceed available funds or configured cap. */
    fun validateBudget(budgetUsdt: BigDecimal, availableUsdt: BigDecimal, leverage: Int): BigDecimal {
        require(budgetUsdt >= BigDecimal("0.1") && budgetUsdt <= BigDecimal("800")) {
            "Configured margin cap must be between $0.10 and $800 USDT"
        }
        require(leverage == 10) { "This bot is configured for fixed x10 leverage" }
        if (availableUsdt <= BigDecimal.ZERO) throw IllegalArgumentException("No available USDT margin")
        val margin = budgetUsdt.min(availableUsdt)
        val notional = margin.multiply(BigDecimal(leverage))
        if (notional <= BigDecimal.ZERO) throw IllegalArgumentException("Available budget leaves no order notional")
        return notional
    }

    /**
     * Default 5m scalping levels are fixed at SL 0.4% and TP 1.2% from actual fill.
     * A caller-supplied structural stop remains supported for other strategies.
     */
    fun levels(entry: BigDecimal, direction: String, stopLossOverride: BigDecimal? = null): RiskLevels {
        require(entry > BigDecimal.ZERO)
        require(direction == "LONG" || direction == "SHORT")
        val stop: BigDecimal
        val target: BigDecimal
        val actualStopFraction: BigDecimal
        val actualTargetFraction: BigDecimal
        if (stopLossOverride != null) {
            stop = stopLossOverride.setScale(12, RoundingMode.HALF_UP).stripTrailingZeros()
            require(if (direction == "LONG") stop < entry else stop > entry) {
                "ATR/structure stop is on the wrong side of actual fill; trade rejected"
            }
            val riskDistance = entry.subtract(stop).abs()
            target = (if (direction == "LONG") entry.add(riskDistance.multiply(BigDecimal("2")))
                else entry.subtract(riskDistance.multiply(BigDecimal("2"))))
                .setScale(12, RoundingMode.HALF_UP).stripTrailingZeros()
            require(target > BigDecimal.ZERO) { "2R target is not a valid positive price" }
            actualStopFraction = riskDistance.divide(entry, 12, RoundingMode.HALF_UP)
            actualTargetFraction = target.subtract(entry).abs().divide(entry, 12, RoundingMode.HALF_UP)
        } else {
            stop = entry.multiply(if (direction == "LONG") BigDecimal.ONE - stopFraction else BigDecimal.ONE + stopFraction)
                .setScale(12, RoundingMode.HALF_UP).stripTrailingZeros()
            target = entry.multiply(if (direction == "LONG") BigDecimal.ONE + targetFraction else BigDecimal.ONE - targetFraction)
                .setScale(12, RoundingMode.HALF_UP).stripTrailingZeros()
            actualStopFraction = stopFraction
            actualTargetFraction = targetFraction
        }
        return RiskLevels(stop, target, actualStopFraction, actualTargetFraction)
    }
}
