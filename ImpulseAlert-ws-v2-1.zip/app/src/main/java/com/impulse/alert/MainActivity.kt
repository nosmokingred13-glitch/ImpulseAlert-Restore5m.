package com.impulse.alert

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var toggle: Button
    private lateinit var armButton: Button
    private lateinit var autoTradeButton: Button
    private lateinit var modeButton: Button
    private lateinit var credentialsButton: Button
    private val h = Handler(Looper.getMainLooper())
    private var n = 0
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            if (n++ % 5 == 0) refreshStats()
            h.postDelayed(this, 1000)
        }
    }

    private fun journalFile() = File(filesDir, "signals.csv")
    private fun tradesFile() = File(filesDir, "trades.csv")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(18, 18, 18))
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) }
        stats = TextView(this).apply { textSize = 14f; setPadding(0, 32, 0, 32); setTextColor(android.graphics.Color.LTGRAY) }
        toggle = Button(this)
        armButton = Button(this)
        autoTradeButton = Button(this)
        modeButton = Button(this)
        credentialsButton = Button(this)
        val battery = Button(this).apply { text = "Вимкнути оптимізацію батареї (важливо)" }
        val share = Button(this).apply { text = "Експорт журналу сигналів (CSV)" }
        val shareTrades = Button(this).apply { text = "Експорт торгових угод (CSV)" }
        val clear = Button(this).apply { text = "Очистити журнал" }

        root.addView(TextView(this).apply {
            text = "Impulse Alert\nBinance Futures • сигнал на вхід"
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE)
        })
        root.addView(status)
        root.addView(toggle)
        root.addView(armButton)
        root.addView(autoTradeButton)
        root.addView(modeButton)
        root.addView(credentialsButton)
        root.addView(stats)
        root.addView(share)
        root.addView(shareTrades)
        root.addView(clear)
        root.addView(battery)
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val prefs = getSharedPreferences("p", MODE_PRIVATE)

        autoTradeButton.setOnClickListener {
            val enabled = !prefs.getBoolean("auto_trade", false)
            if (enabled && ApiCredentialsStore(this).read() == null) {
                Toast.makeText(this, "Спочатку додай API-ключі Binance Demo", Toast.LENGTH_LONG).show()
                showCredentialsDialog()
            } else {
                prefs.edit().putBoolean("auto_trade", enabled).apply()
                if (enabled) {
                    prefs.edit().putBoolean("live_trading", false).apply()
                    Toast.makeText(this, "Автоторгівля увімкнена тільки в DEMO", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this, "Автоторгівлю вимкнено", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }

        modeButton.setOnClickListener {
            val live = prefs.getBoolean("live_trading", false)
            if (!live) {
                AlertDialog.Builder(this)
                    .setTitle("Увімкнути LIVE Futures?")
                    .setMessage("Це надсилатиме реальні ордери й може призвести до втрати коштів. Спочатку перевір Demo. Ви свідомо підтверджуєте перехід у LIVE?")
                    .setNegativeButton("Скасувати", null)
                    .setPositiveButton("Так, дозволяю LIVE") { _, _ ->
                        prefs.edit().putBoolean("live_trading", true).apply()
                        Toast.makeText(this, "LIVE вибрано. Переконайся, що API-ключ саме від реального акаунта.", Toast.LENGTH_LONG).show()
                        refresh()
                    }.show()
            } else {
                prefs.edit().putBoolean("live_trading", false).apply()
                Toast.makeText(this, "Повернуто DEMO", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }

        credentialsButton.setOnClickListener { showCredentialsDialog() }

        armButton.setOnClickListener {
            val enable = !MonitorService.awaitingSignal
            MonitorService.awaitingSignal = enable
            prefs.edit().putBoolean("awaiting_signal", enable).apply()
            if (enable) {
                if (!MonitorService.running) {
                    prefs.edit().putBoolean("on", true).apply()
                    startForegroundService(Intent(this, MonitorService::class.java).setAction(MonitorService.ACTION_SCAN))
                } else {
                    startService(Intent(this, MonitorService::class.java).setAction(MonitorService.ACTION_SCAN))
                }
            }
            refresh()
            Toast.makeText(this, if (enable) "Скан активовано: чекаю підтверджений сетап" else "Очікування сигналу вимкнено", Toast.LENGTH_SHORT).show()
        }

        toggle.setOnClickListener {
            if (MonitorService.running) {
                stopService(Intent(this, MonitorService::class.java))
                prefs.edit().putBoolean("on", false).apply()
            } else {
                startForegroundService(Intent(this, MonitorService::class.java))
                prefs.edit().putBoolean("on", true).apply()
            }
            refresh()
        }

        battery.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        share.setOnClickListener {
            val f = journalFile()
            if (!f.exists()) {
                Toast.makeText(this, "Журнал порожній", Toast.LENGTH_SHORT).show()
            } else {
                val uri = FileProvider.getUriForFile(this, "com.impulse.alert.files", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Експорт журналу"))
            }
        }

        shareTrades.setOnClickListener {
            val f = tradesFile()
            if (!f.exists()) {
                Toast.makeText(this, "Журнал угод порожній", Toast.LENGTH_SHORT).show()
            } else {
                val uri = FileProvider.getUriForFile(this, "com.impulse.alert.files", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Експорт торгових угод"))
            }
        }

        clear.setOnClickListener {
            journalFile().delete()
            refreshStats()
        }

        if (prefs.getBoolean("on", false) && !MonitorService.running)
            startForegroundService(Intent(this, MonitorService::class.java))
    }

    override fun onResume() { super.onResume(); n = 0; h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun refresh() {
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        toggle.text = if (MonitorService.running) "ЗУПИНИТИ" else "ЗАПУСТИТИ"
        autoTradeButton.text = if (prefs.getBoolean("auto_trade", false)) "АВТОТОРГІВЛЯ: УВІМКНЕНО" else "АВТОТОРГІВЛЯ: ВИМКНЕНО"
        modeButton.text = if (prefs.getBoolean("live_trading", false)) "РЕЖИМ: LIVE (РИЗИК)" else "РЕЖИМ: DEMO"
        credentialsButton.text = if (ApiCredentialsStore(this).read() == null) "Додати API-ключі Binance" else "Оновити API-ключі Binance"
        status.text = "Статус: ${MonitorService.status}" + (if (MonitorService.statsLine.isNotBlank()) "\n" + MonitorService.statsLine else "")
        armButton.text = if (MonitorService.awaitingSignal) "СКАНУВАННЯ: ОЧІКУЮ СИГНАЛ" else "СКАНУВАТИ НАСТУПНИЙ СЕТАП"
    }

    private fun showCredentialsDialog() {
        val store = ApiCredentialsStore(this)
        val keyInput = EditText(this).apply {
            hint = "Binance API Key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
        }
        val secretInput = EditText(this).apply {
            hint = "Binance API Secret"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 8, 48, 0)
            addView(keyInput)
            addView(secretInput)
        }
        AlertDialog.Builder(this)
            .setTitle("API-ключі Binance")
            .setMessage("Для першого тесту використовуй Demo Futures ключі. Не вмикай дозвіл на виведення коштів.")
            .setView(box)
            .setNegativeButton("Скасувати", null)
            .setNeutralButton("Видалити ключі") { _, _ ->
                store.clear()
                getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("auto_trade", false).putBoolean("live_trading", false).apply()
                refresh()
            }
            .setPositiveButton("Зашифрувати й зберегти") { _, _ ->
                try {
                    store.save(keyInput.text.toString().trim(), secretInput.text.toString().trim())
                    getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("live_trading", false).putBoolean("auto_trade", false).apply()
                    Toast.makeText(this, "Ключі зашифровано локальним Android Keystore. Автоторгівля залишається вимкненою.", Toast.LENGTH_LONG).show()
                    refresh()
                } catch (e: Exception) {
                    Toast.makeText(this, "Не вдалося зберегти ключі: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun refreshStats() {
        stats.text = SignalJournal.statsText(journalFile()) +
            "\nВідстежується зараз: ${MonitorService.trackedCount}"
    }
}
