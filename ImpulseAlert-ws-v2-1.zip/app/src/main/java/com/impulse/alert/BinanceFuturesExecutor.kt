package com.impulse.alert

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class BinancePositionSnapshot(
    val symbol: String,
    val amount: java.math.BigDecimal,
    val entryPrice: java.math.BigDecimal,
    val markPrice: java.math.BigDecimal
)

data class BinanceOrderResult(
    val symbol: String, val orderId: Long, val clientOrderId: String,
    val status: String, val executedQty: String, val avgPrice: String
)

class BinanceApiException(val httpStatus: Int, val apiCode: Int?, message: String) :
    IOException("Binance HTTP $httpStatus API=$apiCode: $message")

/** USDⓈ-M Futures REST client. Demo endpoint is the default and live trading is opt-in. */
class BinanceFuturesExecutor(
    private val apiKey: String,
    private val secretKey: String,
    private val baseUrl: String = DEMO_BASE_URL,
    private val recvWindow: Long = 5_000,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS).callTimeout(12, TimeUnit.SECONDS).build(),
    private val log: (String) -> Unit = {}
) {
    init {
        require(apiKey.isNotBlank() && secretKey.isNotBlank()) { "Binance API key/secret are required" }
        require(baseUrl == DEMO_BASE_URL || baseUrl == LIVE_BASE_URL) { "Unsupported Futures endpoint" }
        require(recvWindow in 1..60_000)
    }

    private fun enc(s: String) = URLEncoder.encode(s, StandardCharsets.UTF_8.name()).replace("+", "%20")
    private fun signature(payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secretKey.toByteArray(StandardCharsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private fun call(method: String, path: String, values: List<Pair<String, String>> = emptyList(), signed: Boolean = false): String {
        val params = if (signed) values + listOf("recvWindow" to recvWindow.toString(), "timestamp" to System.currentTimeMillis().toString()) else values
        val query = params.joinToString("&") { "${enc(it.first)}=${enc(it.second)}" }
        val finalQuery = if (signed) "$query&signature=${signature(query)}" else query
        val url = if (method == "GET" || method == "DELETE" || (!signed && method == "POST")) {
            "$baseUrl$path".toHttpUrl().newBuilder().apply {
                if (finalQuery.isNotEmpty()) {
                    params.forEach { addQueryParameter(it.first, it.second) }
                    if (signed) addQueryParameter("signature", signature(query))
                }
            }.build()
        } else "$baseUrl$path".toHttpUrl()
        val builder = Request.Builder().url(url).header("X-MBX-APIKEY", apiKey)
        when (method) {
            "GET" -> builder.get()
            "DELETE" -> builder.delete()
            "POST" -> {
                val body = if (signed) finalQuery.toRequestBody("application/x-www-form-urlencoded; charset=utf-8".toMediaType())
                    else FormBody.Builder().apply { params.forEach { add(it.first, it.second) } }.build()
                builder.post(body)
            }
            else -> error("Unsupported method")
        }
        client.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val j = runCatching { JSONObject(body) }.getOrNull()
                val code = if (j?.has("code") == true) j.optInt("code") else null
                // Preserve Binance's exact rejection text/body for diagnostics (e.g. PRICE_FILTER -4014).
                val msg = j?.optString("msg")?.takeIf { it.isNotBlank() }
                    ?: body.ifBlank { "Request failed with an empty response body" }
                log("BINANCE_ORDER_REJECTED method=$method path=$path HTTP=${response.code} API=$code body=$body")
                throw BinanceApiException(response.code, code, msg)
            }
            return body
        }
    }

    fun accountJson(): JSONObject = JSONObject(call("GET", "/fapi/v2/account", signed = true))
    fun exchangeInfoJson(): JSONObject = JSONObject(call("GET", "/fapi/v1/exchangeInfo"))
    fun price(symbol: String): java.math.BigDecimal =
        java.math.BigDecimal(JSONObject(call("GET", "/fapi/v1/ticker/price", listOf("symbol" to symbol))).getString("price"))

    fun availableUsdt(): java.math.BigDecimal {
        val account = accountJson()
        val assets = account.optJSONArray("assets") ?: JSONArray()
        for (i in 0 until assets.length()) {
            val asset = assets.getJSONObject(i)
            if (asset.optString("asset") == "USDT") return java.math.BigDecimal(asset.optString("availableBalance", "0"))
        }
        return java.math.BigDecimal.ZERO
    }

    fun walletBalanceUsdt(): java.math.BigDecimal =
        accountJson().optString("totalWalletBalance", "0").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO

    /** Binance closePosition/close-all protection below is only enabled for one-way mode. */
    fun requireOneWayPositionMode() {
        val mode = JSONObject(call("GET", "/fapi/v1/positionSide/dual", signed = true))
        if (mode.optBoolean("dualSidePosition", false)) {
            throw IllegalStateException("Hedge Mode is enabled. Switch Binance USDⓈ-M Futures to One-way Mode before enabling automatic trading; entry blocked for safety.")
        }
    }

    /** Signed position quantity for a symbol. In one-way mode there should be one non-zero row at most. */
    fun positionAmount(symbol: String): java.math.BigDecimal {
        val positions = JSONArray(call("GET", "/fapi/v2/positionRisk", listOf("symbol" to symbol), signed = true))
        var amount = java.math.BigDecimal.ZERO
        for (i in 0 until positions.length()) {
            val row = positions.optJSONObject(i) ?: continue
            val value = row.optString("positionAmt", "0").toBigDecimalOrNull() ?: continue
            if (row.optString("symbol") == symbol && value.compareTo(java.math.BigDecimal.ZERO) != 0) {
                amount = value
            }
        }
        return amount
    }

    /** Entry price reported by Binance for a currently open position, useful if MARKET RESULT omits avgPrice. */
    fun positionEntryPrice(symbol: String): java.math.BigDecimal {
        val positions = JSONArray(call("GET", "/fapi/v2/positionRisk", listOf("symbol" to symbol), signed = true))
        for (i in 0 until positions.length()) {
            val row = positions.optJSONObject(i) ?: continue
            if (row.optString("symbol") != symbol) continue
            val amount = row.optString("positionAmt", "0").toBigDecimalOrNull() ?: continue
            val entryPrice = row.optString("entryPrice", "0").toBigDecimalOrNull() ?: continue
            if (amount.compareTo(java.math.BigDecimal.ZERO) != 0 && entryPrice > java.math.BigDecimal.ZERO) {
                return entryPrice
            }
        }
        return java.math.BigDecimal.ZERO
    }

    /** Open positions with mark prices, used by the M5 breakeven manager. */
    fun positionSnapshots(): List<BinancePositionSnapshot> {
        val positions = JSONArray(call("GET", "/fapi/v2/positionRisk", signed = true))
        val result = ArrayList<BinancePositionSnapshot>()
        for (i in 0 until positions.length()) {
            val row = positions.optJSONObject(i) ?: continue
            val amount = row.optString("positionAmt", "0").toBigDecimalOrNull() ?: continue
            if (amount.compareTo(java.math.BigDecimal.ZERO) == 0) continue
            val entry = row.optString("entryPrice", "0").toBigDecimalOrNull() ?: continue
            val mark = row.optString("markPrice", "0").toBigDecimalOrNull() ?: continue
            if (entry > java.math.BigDecimal.ZERO && mark > java.math.BigDecimal.ZERO) {
                result.add(BinancePositionSnapshot(row.optString("symbol"), amount, entry, mark))
            }
        }
        return result
    }

    /** Query active conditional algo orders for a symbol. */
    fun openAlgoOrders(symbol: String): JSONArray {
        val raw = call("GET", "/fapi/v1/algoOpenOrders", listOf("symbol" to symbol), signed = true)
        val parsed = org.json.JSONTokener(raw).nextValue()
        return when (parsed) {
            is JSONArray -> parsed
            is JSONObject -> parsed.optJSONArray("orders") ?: parsed.optJSONArray("algoOrders") ?: JSONArray()
            else -> JSONArray()
        }
    }

    /** Current non-zero Futures positions, used to enforce the account's open-trade limit. */
    fun openPositions(): Set<String> {
        val positions = JSONArray(call("GET", "/fapi/v2/positionRisk", signed = true))
        val open = linkedSetOf<String>()
        for (i in 0 until positions.length()) {
            val row = positions.optJSONObject(i) ?: continue
            val amount = row.optString("positionAmt", "0").toBigDecimalOrNull() ?: continue
            if (amount.compareTo(java.math.BigDecimal.ZERO) != 0) open.add(row.optString("symbol"))
        }
        return open
    }

    fun setLeverage(symbol: String, leverage: Int): JSONObject {
        require(leverage == 10) { "ImpulseAlert is configured for fixed x10 leverage" }
        return JSONObject(call("POST", "/fapi/v1/leverage", listOf("symbol" to symbol, "leverage" to leverage.toString()), signed = true))
    }

    /**
     * LIMIT entry using GTC (not post-only). The order may execute as maker or taker depending on market price.
     * Waits up to 90 seconds for a fill, then cancels any remainder. There is no MARKET entry fallback.
     */
    fun makerLimitEntry(symbol: String, side: String, quantity: String, price: String, clientOrderId: String): BinanceOrderResult {
        require(side == "BUY" || side == "SELL")
        require(quantity.toBigDecimalOrNull()?.let { it > java.math.BigDecimal.ZERO } == true)
        require(price.toBigDecimalOrNull()?.let { it > java.math.BigDecimal.ZERO } == true)
        val created = JSONObject(call("POST", "/fapi/v1/order", listOf(
            "symbol" to symbol, "side" to side, "type" to "LIMIT", "timeInForce" to "GTC",
            "quantity" to quantity, "price" to price, "newClientOrderId" to clientOrderId,
            "newOrderRespType" to "RESULT"
        ), signed = true))
        val orderId = created.optLong("orderId", 0L)
        require(orderId > 0L) { "Binance did not return a valid maker LIMIT order id: $created" }
        val deadline = System.currentTimeMillis() + 90_000L
        var latest = created
        while (System.currentTimeMillis() < deadline) {
            val state = latest.optString("status", "UNKNOWN")
            if (state == "FILLED" || state == "CANCELED" || state == "EXPIRED" || state == "REJECTED") break
            Thread.sleep(1_000L)
            latest = queryRegularOrder(symbol, clientOrderId)
            if (latest.optString("status") == "FILLED") break
        }
        if (latest.optString("status") !in setOf("FILLED", "CANCELED", "EXPIRED", "REJECTED")) {
            runCatching { cancelRegularOrder(symbol, orderId) }
                .onFailure { log("MAKER_ENTRY_CANCEL_FAILED $symbol orderId=$orderId: ${it.message}") }
            latest = runCatching { queryRegularOrder(symbol, clientOrderId) }.getOrDefault(latest)
        }
        val qty = latest.optString("executedQty", created.optString("executedQty", "0"))
        val avgRaw = latest.optString("avgPrice", created.optString("avgPrice", "0"))
        val avg = avgRaw.toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO
        val executed = qty.toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO
        val quote = latest.optString("cumQuote", latest.optString("cumQuoteQty", "0")).toBigDecimalOrNull()
            ?: java.math.BigDecimal.ZERO
        val resolvedAvg = if (avg > java.math.BigDecimal.ZERO) avg.toPlainString()
            else if (executed > java.math.BigDecimal.ZERO && quote > java.math.BigDecimal.ZERO)
                quote.divide(executed, java.math.MathContext.DECIMAL128).stripTrailingZeros().toPlainString()
            else "0"
        return BinanceOrderResult(symbol, latest.optLong("orderId", orderId),
            latest.optString("clientOrderId", clientOrderId), latest.optString("status", "UNKNOWN"), qty, resolvedAvg)
    }
    fun marketOrder(symbol: String, side: String, quantity: String, clientOrderId: String, reduceOnly: Boolean = false): BinanceOrderResult {
        require(side == "BUY" || side == "SELL")
        val json = JSONObject(call("POST", "/fapi/v1/order", listOf(
            "symbol" to symbol, "side" to side, "type" to "MARKET", "quantity" to quantity,
            "newClientOrderId" to clientOrderId, "newOrderRespType" to "RESULT"
        ) + if (reduceOnly) listOf("reduceOnly" to "true") else emptyList(), signed = true))
        val executedQty = json.optString("executedQty", "0")
        val rawAvgPrice = json.optString("avgPrice", "0")
        val avg = rawAvgPrice.toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO
        val qty = executedQty.toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO
        val cumQuote = (json.optString("cumQuote", "0").toBigDecimalOrNull()
            ?: json.optString("cumQuoteQty", "0").toBigDecimalOrNull()
            ?: java.math.BigDecimal.ZERO)
        // Binance can return avgPrice=0 on a MARKET RESULT response even when it filled.
        // Recover the weighted average from the executed quote quantity rather than falsely
        // treating a real fill as invalid and immediately closing it.
        val resolvedAvgPrice = if (avg > java.math.BigDecimal.ZERO) {
            avg.toPlainString()
        } else if (qty > java.math.BigDecimal.ZERO && cumQuote > java.math.BigDecimal.ZERO) {
            val derived = cumQuote.divide(qty, java.math.MathContext.DECIMAL128)
            log("MARKET_FILL_AVGPRICE_FALLBACK ${symbol} orderId=${json.optLong("orderId", -1)} avgPrice=${rawAvgPrice} cumQuote=${cumQuote} executedQty=${qty} derivedAvgPrice=${derived}")
            derived.stripTrailingZeros().toPlainString()
        } else {
            log("MARKET_FILL_AVGPRICE_UNRESOLVED ${symbol} orderId=${json.optLong("orderId", -1)} status=${json.optString("status")} executedQty=${executedQty} avgPrice=${rawAvgPrice} cumQuote=${cumQuote}")
            "0"
        }
        return BinanceOrderResult(symbol, json.optLong("orderId", -1), json.optString("clientOrderId", clientOrderId),
            json.optString("status", "UNKNOWN"), executedQty, resolvedAvgPrice)
    }

    /** Recent realized PnL for a symbol since the supplied epoch milliseconds. Null means Binance returned no matching records. */
    fun realizedPnlSince(symbol: String, startTimeMs: Long): java.math.BigDecimal? {
        val now = System.currentTimeMillis()
        val raw = call("GET", "/fapi/v1/income", listOf(
            "symbol" to symbol, "incomeType" to "REALIZED_PNL",
            "startTime" to startTimeMs.coerceAtLeast(0L).toString(),
            "endTime" to now.toString(), "limit" to "1000"
        ), signed = true)
        val rows = JSONArray(raw)
        if (rows.length() == 0) return null
        var total = java.math.BigDecimal.ZERO
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            total = total.add(row.optString("income", "0").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO)
        }
        return total
    }

    /** Current regular open orders for a symbol (used to clean up our stale LIMIT take-profits). */
    fun openRegularOrders(symbol: String): JSONArray =
        JSONArray(call("GET", "/fapi/v1/openOrders", listOf("symbol" to symbol), signed = true))

    fun cancelRegularOrder(symbol: String, orderId: Long): JSONObject {
        require(orderId > 0L)
        return JSONObject(call("DELETE", "/fapi/v1/order", listOf(
            "symbol" to symbol, "orderId" to orderId.toString()
        ), signed = true))
    }

    /** Place a reduce-only LIMIT take-profit after STOP_MARKET has been confirmed. */
    fun limitCloseOrder(symbol: String, exitSide: String, quantity: String, price: String, clientOrderId: String): JSONObject {
        require(exitSide == "BUY" || exitSide == "SELL")
        require(quantity.toBigDecimalOrNull()?.let { it > java.math.BigDecimal.ZERO } == true)
        require(price.toBigDecimalOrNull()?.let { it > java.math.BigDecimal.ZERO } == true)
        return JSONObject(call("POST", "/fapi/v1/order", listOf(
            "symbol" to symbol, "side" to exitSide, "type" to "LIMIT",
            "timeInForce" to "GTC", "quantity" to quantity, "price" to price,
            "reduceOnly" to "true", "newClientOrderId" to clientOrderId,
            "newOrderRespType" to "RESULT"
        ), signed = true))
    }

    fun queryRegularOrder(symbol: String, clientOrderId: String): JSONObject =
        JSONObject(call("GET", "/fapi/v1/order", listOf(
            "symbol" to symbol, "origClientOrderId" to clientOrderId
        ), signed = true))

    /** Conditional Futures orders have migrated to /fapi/v1/algoOrder; use triggerPrice, not stopPrice. */
    fun conditionalCloseAll(symbol: String, exitSide: String, type: String, triggerPrice: String, clientAlgoId: String): JSONObject {
        require(exitSide == "BUY" || exitSide == "SELL")
        require(type == "STOP_MARKET" || type == "TAKE_PROFIT_MARKET")
        return JSONObject(call("POST", "/fapi/v1/algoOrder", listOf(
            "algoType" to "CONDITIONAL", "symbol" to symbol, "side" to exitSide, "type" to type,
            "triggerPrice" to triggerPrice, "closePosition" to "true", "workingType" to "MARK_PRICE",
            "clientAlgoId" to clientAlgoId
        ), signed = true))
    }

    /** Re-query an accepted conditional order from Binance instead of trusting POST acknowledgement alone. */
    fun queryAlgoOrder(symbol: String, algoId: Long): JSONObject {
        require(algoId > 0L)
        return JSONObject(call("GET", "/fapi/v1/algoOrder", listOf(
            "symbol" to symbol, "algoId" to algoId.toString()
        ), signed = true))
    }

    fun cancelAlgoOrder(symbol: String, algoId: Long): JSONObject {
        require(algoId > 0L)
        return JSONObject(call("DELETE", "/fapi/v1/algoOrder", listOf(
            "symbol" to symbol, "algoId" to algoId.toString()
        ), signed = true))
    }

    companion object {
        const val DEMO_BASE_URL = "https://demo-fapi.binance.com"
        const val LIVE_BASE_URL = "https://fapi.binance.com"
    }
}

/** Small Android-Keystore-backed encrypted storage for API credentials. */
class ApiCredentialsStore(context: Context) {
    private val prefs = context.getSharedPreferences("encrypted_binance_credentials", Context.MODE_PRIVATE)
    private val alias = "ImpulseAlertBinanceCredentialsV1"

    private fun key(): SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val bytes = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
    }

    fun save(apiKey: String, secret: String) {
        require(apiKey.isNotBlank() && secret.isNotBlank())
        prefs.edit().putString("key", encrypt(apiKey)).putString("secret", encrypt(secret)).apply()
    }
    fun read(): Pair<String, String>? {
        return try {
            val k = prefs.getString("key", null) ?: return null
            val s = prefs.getString("secret", null) ?: return null
            decrypt(k) to decrypt(s)
        } catch (_: Exception) { null }
    }
    fun clear() { prefs.edit().clear().apply() }
}
