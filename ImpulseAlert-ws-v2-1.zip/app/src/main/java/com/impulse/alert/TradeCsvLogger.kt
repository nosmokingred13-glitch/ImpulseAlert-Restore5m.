package com.impulse.alert

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TradeCsvLogger(context: Context) {
    val file: File = File(context.filesDir, "trades.csv")
    private val lock = Any()
    private val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US)

    init {
        synchronized(lock) {
            if (!file.exists() || file.length() == 0L) {
                file.parentFile?.mkdirs()
                file.writeText("time,event,symbol,dir,entry,qty,sl,tp,result,pnl,details\n")
            }
        }
    }

    fun entry(symbol: String, direction: String, entry: String, qty: String, sl: String, tp: String, result: String = "OPEN") =
        append(listOf(now(), "ENTRY", symbol, direction, entry, qty, sl, tp, result, "", ""))

    fun exit(symbol: String, direction: String, entry: String, qty: String, sl: String, tp: String, result: String, pnl: String, details: String = "") =
        append(listOf(now(), "EXIT", symbol, direction, entry, qty, sl, tp, result, pnl, details))

    fun error(symbol: String, direction: String, details: String) =
        append(listOf(now(), "ERROR", symbol, direction, "", "", "", "", "REJECTED", "", details))

    /** Summary of closed trades (EXIT rows). PnL is REALIZED_PNL from Binance income, i.e. before commissions. */
    fun statsLine(): String {
        var wins = 0; var losses = 0
        var pnl = java.math.BigDecimal.ZERO
        synchronized(lock) {
            file.readLines().drop(1).forEach { line ->
                val f = line.trim().removePrefix("\"").removeSuffix("\"").split("\",\"")
                if (f.size >= 10 && f[1] == "EXIT") {
                    val p = f[9].toBigDecimalOrNull() ?: return@forEach
                    pnl = pnl.add(p)
                    if (p.signum() >= 0) wins++ else losses++
                }
            }
        }
        val n = wins + losses
        if (n == 0) return "Статистика: закритих угод ще немає"
        val sign = if (pnl.signum() > 0) "+" else ""
        return "Угод: $n • Вінрейт: ${wins * 100 / n}% ($wins/$losses) • PnL: $sign${pnl.setScale(4, java.math.RoundingMode.HALF_UP).toPlainString()} USDT (без комісій)"
    }

    private fun now() = formatter.format(Date())
    private fun append(values: List<String>) = synchronized(lock) {
        file.appendText(values.joinToString(",") { "\"${it.replace("\"", "\"\"").replace("\n", " ")}\"" } + "\n")
    }

    /** Export to a URI returned by ACTION_CREATE_DOCUMENT. */
    fun exportTo(uri: Uri, context: Context) {
        context.contentResolver.openOutputStream(uri, "wt").use { output ->
            val stream = requireNotNull(output) { "Cannot open CSV export destination" }
            FileInputStream(file).use { input -> input.copyTo(stream) }
            stream.flush()
        }
    }
}
