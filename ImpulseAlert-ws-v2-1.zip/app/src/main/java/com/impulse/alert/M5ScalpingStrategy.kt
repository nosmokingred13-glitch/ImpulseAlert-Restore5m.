package com.impulse.alert

import org.json.JSONArray
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs
import kotlin.math.max

/**
 * M5 impulse confirmation and ATR risk plan.
 * Input rows must be Binance Futures klines. The currently forming candle is excluded.
 */
data class M5Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val quoteVolume: Double,
    val closeTime: Long
)

data class M5Setup(
    val symbol: String,
    val direction: String,
    val impulseMid: Double,
    val impulseHigh: Double,
    val impulseLow: Double,
    val atr: Double,
    val stopLoss: BigDecimal,
    val ema50: Double,
    val volumeRatio: Double,
    val bodyRatio: Double
)

object M5ScalpingStrategy {
    private const val MIN_VOLUME_RATIO = 3.0
    private const val MAX_VOLUME_RATIO = 8.0
    private const val REJECT_VOLUME_ABOVE = 10.0
    private const val MIN_BODY_RATIO = 0.65
    private const val ATR_PERIOD = 14
    private const val ATR_BUFFER = 0.15

    fun parseClosedCandles(rows: JSONArray, now: Long = System.currentTimeMillis()): List<M5Candle> {
        val result = ArrayList<M5Candle>()
        for (i in 0 until rows.length()) {
            val row = rows.optJSONArray(i) ?: continue
            if (row.length() < 8) continue
            val closeTime = row.optLong(6, Long.MAX_VALUE)
            if (closeTime >= now) continue
            val candle = M5Candle(
                openTime = row.optLong(0),
                open = row.optString(1).toDoubleOrNull() ?: continue,
                high = row.optString(2).toDoubleOrNull() ?: continue,
                low = row.optString(3).toDoubleOrNull() ?: continue,
                close = row.optString(4).toDoubleOrNull() ?: continue,
                quoteVolume = row.optString(7).toDoubleOrNull() ?: continue,
                closeTime = closeTime
            )
            if (candle.open > 0 && candle.low > 0 && candle.high >= candle.low &&
                candle.close > 0 && candle.quoteVolume >= 0) result.add(candle)
        }
        return result
    }

    fun evaluate(symbol: String, direction: String, candles: List<M5Candle>): M5Setup? {
        if (direction != "LONG" && direction != "SHORT") return null
        if (candles.size < 60) return null
        val impulse = candles.last()
        val range = impulse.high - impulse.low
        if (range <= 0.0) return null
        val bodyRatio = abs(impulse.close - impulse.open) / range
        if (bodyRatio < MIN_BODY_RATIO) return null
        if (direction == "LONG" && impulse.close <= impulse.open) return null
        if (direction == "SHORT" && impulse.close >= impulse.open) return null

        val avgQuoteVolume = candles.dropLast(1).takeLast(20).map { it.quoteVolume }.average()
        if (avgQuoteVolume <= 0.0) return null
        val volumeRatio = impulse.quoteVolume / avgQuoteVolume
        if (volumeRatio > REJECT_VOLUME_ABOVE || volumeRatio < MIN_VOLUME_RATIO || volumeRatio > MAX_VOLUME_RATIO) return null

        val closes = candles.map { it.close }
        val ema50 = ema(closes, 50)
        if (direction == "LONG" && impulse.close <= ema50) return null
        if (direction == "SHORT" && impulse.close >= ema50) return null

        val atr = atr(candles, ATR_PERIOD)
        if (!atr.isFinite() || atr <= 0.0) return null
        val buffer = atr * ATR_BUFFER
        val rawStop = if (direction == "LONG") impulse.low - buffer else impulse.high + buffer
        if (direction == "LONG" && rawStop >= impulse.close) return null
        if (direction == "SHORT" && rawStop <= impulse.close) return null

        return M5Setup(
            symbol = symbol,
            direction = direction,
            impulseMid = (impulse.high + impulse.low) / 2.0,
            impulseHigh = impulse.high,
            impulseLow = impulse.low,
            atr = atr,
            stopLoss = BigDecimal.valueOf(rawStop).setScale(12, RoundingMode.HALF_UP).stripTrailingZeros(),
            ema50 = ema50,
            volumeRatio = volumeRatio,
            bodyRatio = bodyRatio
        )
    }

    /** Current price must retest the impulse midpoint, then reclaim the midpoint in signal direction. */
    fun retestConfirmed(setup: M5Setup, price: Double): Boolean {
        if (!price.isFinite() || price <= 0.0) return false
        return if (setup.direction == "LONG") price >= setup.impulseMid && price <= setup.impulseHigh
        else price <= setup.impulseMid && price >= setup.impulseLow
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val alpha = 2.0 / (period + 1.0)
        var value = values.first()
        for (i in 1 until values.size) value += alpha * (values[i] - value)
        return value
    }

    private fun atr(candles: List<M5Candle>, period: Int): Double {
        val start = max(1, candles.size - period)
        val trueRanges = ArrayList<Double>()
        for (i in start until candles.size) {
            val c = candles[i]
            val prevClose = candles[i - 1].close
            trueRanges.add(max(c.high - c.low, max(abs(c.high - prevClose), abs(c.low - prevClose))))
        }
        return trueRanges.average()
    }
}
