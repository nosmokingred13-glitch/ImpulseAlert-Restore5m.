package com.impulse.alert

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import okhttp3.*
import org.json.JSONArray
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentSkipListMap
import java.util.concurrent.atomic.AtomicInteger

class MonitorService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var status = "Зупинено"
        @Volatile var statsLine = ""
        private const val WS_URL = "wss://fstream.binance.com/market/ws/!miniTicker@arr"
        private const val CH_SERVICE = "service_v1"
        private const val CH_ALERT = "alerts_v1"
        private const val SERVICE_ID = 1
        @Volatile var trackedCount = 0
        @Volatile var awaitingSignal = false
        const val ACTION_SCAN = "com.impulse.alert.ACTION_SCAN"

        @Synchronized fun consumeAwaitingSignal(): Boolean {
            if (!awaitingSignal) return false
            awaitingSignal = false
            return true
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var ws: WebSocket? = null
    // Dedicated raw Futures socket for candle streams; ticker socket remains unchanged.
    @Volatile private var klineWs: WebSocket? = null
    @Volatile private var klineSocketReady = false
    private val klineSocketLock = Any()
    private var generation = 0
    @Volatile private var lastMsg = 0L
    @Volatile private var frameCount = 0L
    @Volatile private var lastParsedCount = 0
    private var backoff = 2_000L
    private var wakeLock: PowerManager.WakeLock? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var hasNetwork = false
    private var msgCount = 0L
    // Latest valid prices held in memory; this is the source for the visible tracked-pair count.
    private val latestPrices = ConcurrentHashMap<String, Double>()
    // Avoid concurrent REST validation requests for the same coin.
    private val pendingEmaChecks = ConcurrentHashMap.newKeySet<String>()
    private val pendingExecutions = ConcurrentHashMap.newKeySet<String>()
    // Emergency REST guard: the live ticker is already WebSocket-fed, but closed 5m
    // candles are still fetched over REST. Never fan out hundreds of klines calls at once.
    private val klineRestGate = Any()
    private var lastKlineRestRequestAt = 0L
    private val lastKlineRestBySymbol = ConcurrentHashMap<String, Long>()
    @Volatile private var restBlockedUntil = 0L
    @Volatile private var shadeText = "Моніторинг активний"
    // Closed 5m candle cache populated by Binance kline WebSocket streams.
    private val candleCache = ConcurrentHashMap<String, ConcurrentSkipListMap<Long, ScalpCandle>>()
    private val subscribedKlines = ConcurrentHashMap.newKeySet<String>()
    private val websocketRequestId = AtomicInteger(100)
    private val breakevenCheckRunning = java.util.concurrent.atomic.AtomicBoolean(false)
    // Cool down a symbol for seven minutes after an observed position exit.
    // The current endpoint flow does not reliably distinguish SL from TP, so this conservative cooldown applies to either exit.
    private val knownOpenSymbols = ConcurrentHashMap.newKeySet<String>()
    private val symbolCooldownUntil = ConcurrentHashMap<String, Long>()
    private val openSinceBySymbol = ConcurrentHashMap<String, Long>()
    @Volatile private var positionSnapshotInitialized = false

    private val breakevenWatchdog = object : Runnable {
        override fun run() {
            checkBreakevenPositions()
            if (running) handler.postDelayed(this, 10_000L)
        }
    }

    private lateinit var journal: SignalJournal

    private val detector = ImpulseDetector { symbol, dir, move, vol, price -> handleDetectedSignal(symbol, dir, move, vol, price) }

    private val connectRunnable = Runnable { connect() }

    private val watchdog = object : Runnable {
        override fun run() {
            val silent = System.currentTimeMillis() - lastMsg
            if (hasNetwork && ws != null && silent > 20_000) {
                status = "Немає кадрів Binance ${silent / 1000}с • перепідключення…"
                connect()
            }
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        journal = SignalJournal(java.io.File(filesDir, "signals.csv"))
        statsLine = runCatching { TradeCsvLogger(this).statsLine() }.getOrDefault("")
        awaitingSignal = getSharedPreferences("p", MODE_PRIVATE).getBoolean("awaiting_signal", false)
        createChannels()
        val notif = buildServiceNotification("Запуск…")
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, SERVICE_ID, notif, type)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ImpulseAlert:ws").apply {
            setReferenceCounted(false)
            acquire()
        }

        registerNetworkCallback()
        handler.postDelayed(watchdog, 10_000)
        handler.postDelayed(breakevenWatchdog, 10_000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SCAN) {
            detector.resetForNewScan()
            status = "Новий скан: збираю свіжі ціни та шукаю ранній сетап…"
            updateServiceNotification()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        awaitingSignal = false
        getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("awaiting_signal", false).apply()
        status = "Зупинено"
        handler.removeCallbacksAndMessages(null)
        netCallback?.let {
            try { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (_: Exception) {}
        }
        generation++
        ws?.cancel()
        ws = null
        klineSocketReady = false
        klineWs?.cancel()
        klineWs = null
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ---------- Мережа ----------

    private fun registerNetworkCallback() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                hasNetwork = true
                backoff = 2_000L
                handler.post {
                    connect()                       // Wi-Fi <-> mobile: ticker socket
                    ensureKlineSocket()             // restore candle subscriptions even before the next signal
                }
            }
            override fun onLost(network: Network) {
                hasNetwork = false
                handler.post {
                    generation++
                    ws?.cancel(); ws = null
                    klineSocketReady = false
                    klineWs?.cancel(); klineWs = null
                    handler.removeCallbacks(connectRunnable)
                    status = "Немає інтернету, чекаю мережу…"
                    updateServiceNotification()
                }
            }
        }
        netCallback = cb
        try { cm.registerDefaultNetworkCallback(cb) } catch (e: Exception) {
            hasNetwork = true; connect()
        }
    }

    // ---------- WebSocket ----------

    private fun connect() {
        handler.removeCallbacks(connectRunnable)
        val gen = ++generation
        try { ws?.cancel() } catch (_: Exception) {}
        latestPrices.clear()
        trackedCount = 0
        status = "Підключення до Binance…"
        lastMsg = System.currentTimeMillis()
        ws = client.newWebSocket(Request.Builder().url(WS_URL).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) return
                detector.clear()                    // розрив у даних — стару історію не використовуємо
                latestPrices.clear()
                trackedCount = 0
                msgCount = 0L
                backoff = 2_000L
                frameCount = 0L
                lastParsedCount = 0
                status = "Підключено ✓ • чекаю перший кадр Binance"
                updateServiceNotification()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation) return
                val now = System.currentTimeMillis()
                lastMsg = now
                frameCount++
                try {
                    if (text.trimStart().startsWith("{")) {
                        val root = org.json.JSONObject(text)
                        val data = root.optJSONObject("data") ?: root
                        if (data.optJSONObject("k") != null) { handleKlineMessage(data); return }
                    }
                    // Binance !miniTicker@arr normally sends a JSON array. Accept a single
                    // object too, so a wrapper/format variation cannot silently leave count at 0.
                    val rows = when (text.trimStart().firstOrNull()) {
                        '[' -> JSONArray(text)
                        '{' -> {
                            val root = org.json.JSONObject(text)
                            when {
                                root.optJSONArray("data") != null -> root.getJSONArray("data")
                                root.optJSONObject("data") != null -> JSONArray().put(root.getJSONObject("data"))
                                else -> JSONArray().put(root)
                            }
                        }
                        else -> JSONArray()
                    }
                    var parsed = 0
                    for (i in 0 until rows.length()) {
                        val o = rows.optJSONObject(i) ?: continue
                        val s = o.optString("s", "").trim()
                        if (s.length < 6 || !s.endsWith("USDT")) continue
                        val price = o.optString("c", "").toDoubleOrNull() ?: continue
                        if (!price.isFinite() || price <= 0.0) continue
                        // Binance miniTicker field "q" is the rolling 24h quote volume.
                        // Reject illiquid pairs BEFORE they enter the active list, detector, or journal.
                        val quoteVol24h = o.optString("q", "0").toDoubleOrNull() ?: 0.0
                        if (!quoteVol24h.isFinite() || quoteVol24h < 0.0) continue

                        // No symbol whitelist or $50M volume cutoff: scan all valid pairs from the all-miniTicker Futures stream.
                        latestPrices[s] = price
                        parsed++
                        detector.onTick(s, price, quoteVol24h, now)
                        journal.onTick(s, price, now)
                    }
                    trackedCount = latestPrices.size
                    lastParsedCount = parsed
                    msgCount++
                    if (msgCount % 5 == 0L) {
                        status = if (trackedCount > 0) {
                            "Підключено ✓ • пар: $trackedCount • кадрів: $frameCount"
                        } else {
                            "Кадри: $frameCount, валідних пар: 0 • перевіряю формат"
                        }
                    }
                    if (msgCount % 30 == 0L) updateServiceNotification()
                } catch (e: Exception) {
                    status = "Помилка розбору WebSocket-кадру: ${e.javaClass.simpleName}"
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen == generation) scheduleReconnect("Binance закрив з’єднання: код $code${if (reason.isNotBlank()) ", $reason" else ""}")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen == generation) {
                    val http = response?.code?.let { " HTTP $it" } ?: ""
                    val detail = t.message?.take(90)?.let { ": $it" } ?: ""
                    scheduleReconnect("WebSocket-збій${http}: ${t.javaClass.simpleName}$detail")
                }
            }
        })
    }

    private fun scheduleReconnect(reason: String) {
        handler.post {
            if (!running) return@post
            status = "$reason. Повтор через ${backoff / 1000}с…"
            updateServiceNotification()
            handler.removeCallbacks(connectRunnable)
            handler.postDelayed(connectRunnable, backoff)
            backoff = (backoff * 2).coerceAtMost(30_000L)
        }
    }

    /** Open one raw USD-M Futures socket and subscribe to per-symbol closed 5m candles. */
    private fun ensureKlineSocket() {
        synchronized(klineSocketLock) {
            if (!running || klineWs != null) return
            try {
                klineWs = client.newWebSocket(Request.Builder().url("wss://fstream.binance.com/ws").build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        synchronized(klineSocketLock) {
                            if (klineWs !== webSocket) return
                            klineSocketReady = true
                        }
                        // Re-subscribe all requested symbols after every reconnect.
                        subscribedKlines.toList().chunked(100).forEach { sendKlineSubscriptions(webSocket, it) }
                    }
                    override fun onMessage(webSocket: WebSocket, text: String) {
                        if (klineWs !== webSocket) return
                        try {
                            val root = org.json.JSONObject(text)
                            val data = root.optJSONObject("data") ?: root
                            if (data.optJSONObject("k") != null) handleKlineMessage(data)
                        } catch (_: Exception) { }
                    }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                        retryKlineSocket(webSocket)
                    }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        retryKlineSocket(webSocket)
                    }
                })
            } catch (e: Exception) {
                klineWs = null
                klineSocketReady = false
                handler.postDelayed({ ensureKlineSocket() }, 5_000L)
            }
        }
    }

    private fun retryKlineSocket(socket: WebSocket) {
        synchronized(klineSocketLock) {
            if (klineWs !== socket) return
            klineWs = null
            klineSocketReady = false
        }
        if (running) handler.postDelayed({ ensureKlineSocket() }, 3_000L)
    }

    private fun sendKlineSubscription(socket: WebSocket, symbol: String) {
        val payload = org.json.JSONObject()
            .put("method", "SUBSCRIBE")
            .put("params", JSONArray().put(symbol.lowercase(java.util.Locale.ROOT) + "@kline_5m"))
            .put("id", websocketRequestId.incrementAndGet())
            .toString()
        socket.send(payload)
    }

    private fun sendKlineSubscriptions(socket: WebSocket, symbols: List<String>) {
        if (symbols.isEmpty()) return
        val params = JSONArray()
        for (symbol in symbols) params.put(symbol.lowercase(java.util.Locale.ROOT) + "@kline_5m")
        socket.send(org.json.JSONObject().put("method", "SUBSCRIBE").put("params", params).put("id", websocketRequestId.incrementAndGet()).toString())
    }

    /**
     * WebSocket-first candle source. Returns the closed-5m window ONLY when it is gap-free and already contains
     * the most recent closed candle, i.e. identical to what a fresh REST snapshot would give. Otherwise null (-> REST seed).
     */
    private fun freshCachedCandles(symbol: String): List<ScalpCandle>? {
        if (!klineSocketReady || !subscribedKlines.contains(symbol)) return null
        val cache = candleCache[symbol] ?: return null
        val list = cache.values.toList()
        if (list.size < 201) return null
        val expectedLastClose = (System.currentTimeMillis() / 300_000L) * 300_000L - 1L
        if (list.last().closeTime < expectedLastClose) return null
        for (i in 1 until list.size) {
            if (list[i].closeTime - list[i - 1].closeTime != 300_000L) { cache.clear(); return null }
        }
        return list
    }

    /** Fill the cache from a REST snapshot (closed candles only) and start streaming the symbol. */
    private fun seedCandleCache(symbol: String, candles: List<ScalpCandle>) {
        val now = System.currentTimeMillis()
        val closed = candles.filter { it.closeTime in 1 until now }
        if (closed.size < 201) return
        val fresh = ConcurrentSkipListMap<Long, ScalpCandle>()
        for (c in closed) fresh[c.closeTime] = c
        val lastSeeded = closed.last().closeTime
        candleCache[symbol]?.let { old -> for ((k, v) in old) if (k > lastSeeded) fresh[k] = v }
        while (fresh.size > 300) fresh.pollFirstEntry()
        candleCache[symbol] = fresh
        if (subscribedKlines.contains(symbol) || subscribedKlines.size < 400) subscribeKline(symbol)
    }

    private fun restSlotAvailable(): Boolean = synchronized(klineRestGate) {
        val now = System.currentTimeMillis()
        if (now < restBlockedUntil || now - lastKlineRestRequestAt < 250L) return@synchronized false
        lastKlineRestRequestAt = now
        true
    }

    private fun subscribeKline(symbol: String) {
        val normalized = symbol.uppercase(java.util.Locale.ROOT)
        val isNew = subscribedKlines.add(normalized)
        val socket = klineWs
        if (socket != null && klineSocketReady) {
            if (isNew) sendKlineSubscription(socket, normalized)
        } else {
            ensureKlineSocket()
        }
    }

    private fun handleKlineMessage(data: org.json.JSONObject) {
        val k = data.optJSONObject("k") ?: return
        if (!k.optBoolean("x", false)) return
        val symbol = k.optString("s", data.optString("s", "")).uppercase(java.util.Locale.ROOT)
        if (symbol.isBlank() || !symbol.endsWith("USDT")) return
        val closeTime = k.optLong("T", 0L)
        val candle = ScalpCandle(
            open = k.optString("o", "").toDoubleOrNull() ?: return,
            high = k.optString("h", "").toDoubleOrNull() ?: return,
            low = k.optString("l", "").toDoubleOrNull() ?: return,
            close = k.optString("c", "").toDoubleOrNull() ?: return,
            quoteVolume = k.optString("q", "").toDoubleOrNull() ?: return,
            closeTime = closeTime
        )
        if (closeTime <= 0L || candle.open <= 0.0 || candle.low <= 0.0 ||
            candle.high < candle.low || candle.close <= 0.0 || candle.quoteVolume < 0.0) return
        val cache = candleCache.computeIfAbsent(symbol) { ConcurrentSkipListMap() }
        cache[closeTime] = candle
        while (cache.size > 300) cache.pollFirstEntry()
    }

    // ---------- Сповіщення ----------

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Фоновий моніторинг", NotificationManager.IMPORTANCE_LOW)
        )
        val alert = NotificationChannel(CH_ALERT, "Імпульси", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 400, 150, 400)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
        }
        nm.createNotificationChannel(alert)
    }

    private fun openAppIntent() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Candidate checks ("перевіряю 5m...", "немає підтвердження"...) are app-only noise; the shade keeps entries, errors and connection state. */
    private fun isCandidateNoise(s: String) = s.contains("5m") || s.contains("пауза після закриття")

    private fun buildServiceNotification(text: String) =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_impulse)
            .setContentTitle("Impulse Alert працює")
            .setContentText(text.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun updateServiceNotification() {
        if (!isCandidateNoise(status)) shadeText = status
        try {
            getSystemService(NotificationManager::class.java)
                .notify(SERVICE_ID, buildServiceNotification(shadeText + (if (statsLine.isNotBlank()) "\n" + statsLine else "")))
        } catch (_: Exception) {}
    }

    private fun handleDetectedSignal(symbol: String, dir: String, move: Double, vol: Double, price: Double) {
        val cooldownUntil = symbolCooldownUntil[symbol] ?: 0L
        if (System.currentTimeMillis() < cooldownUntil) {
            status = symbol + ": пауза після закриття позиції ще " + ((cooldownUntil - System.currentTimeMillis()) / 1000) + "с"
            updateServiceNotification()
            return
        }
        if (!pendingEmaChecks.add(symbol)) return
        status = "Перевіряю 5m scalp: $symbol • EMA200 / RSI8 / BB(20,2) • LIMIT maker…"
        updateServiceNotification()
        // Restore the previous proven signal path: live impulse comes from the ticker WebSocket,
        // while every candidate is evaluated against a fresh Binance 5m Futures REST snapshot.
        // WebSocket-first: closed 5m candles come from the kline-stream cache (same data as REST, no API weight).
        // REST is used only to seed/repair the cache, throttled, and never while Binance has rate-limited us.
        val cached = freshCachedCandles(symbol)
        if (cached != null) {
            evaluateCachedSetup(symbol, cached, move)
            return
        }
        if (!restSlotAvailable()) {
            pendingEmaChecks.remove(symbol); detector.allowRetry(symbol)
            return
        }
        val request = Request.Builder().url("https://fapi.binance.com/fapi/v1/klines?symbol=$symbol&interval=5m&limit=300").get().build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                pendingEmaChecks.remove(symbol); detector.allowRetry(symbol)
                status = "5m klines недоступні для $symbol • сигнал пропущено"; updateServiceNotification()
            }
            override fun onResponse(call: Call, response: Response) {
                val code = response.code
                if (code == 429 || code == 418) restBlockedUntil = System.currentTimeMillis() + (if (code == 418) 300_000L else 60_000L)
                val body = try { if (!response.isSuccessful) null else response.body?.string() } finally { response.close() }
                if (body.isNullOrBlank()) {
                    pendingEmaChecks.remove(symbol); detector.allowRetry(symbol)
                    status = "Binance 5m HTTP $code / порожня відповідь для $symbol"; updateServiceNotification(); return
                }
                try {
                    val candles = M5BollingerStrategy.parseCandles(JSONArray(body))
                    seedCandleCache(symbol, candles)
                    val setup = M5BollingerStrategy.evaluate(candles)
                    if (setup == null) {
                        detector.allowRetry(symbol)
                        status = "$symbol: немає підтвердження 5m (EMA200 + RSI8 + BB20/2)"; updateServiceNotification(); return
                    }
                    // Analytics only: keep journal entry without affecting direction or execution.
                    journal.add(symbol, setup.direction, setup.referencePrice.toDouble(), move, setup.volumeRatio, System.currentTimeMillis())
                    status = symbol + " " + setup.direction + ": 5m LIMIT MAKER • EMA200 / RSI8=" + String.format(java.util.Locale.US, "%.1f", setup.rsi8) +
                        " • vol=" + String.format(java.util.Locale.US, "%.2f", setup.volumeRatio) + "x • SL " + fmt(setup.stopLoss.toDouble()) + " • TP " + fmt(setup.takeProfit.toDouble())
                    updateServiceNotification()
                    // Same previous execution path: GTC LIMIT at the Bollinger edge; no MARKET fallback.
                    executeAutoTradeIfEnabled(symbol, setup.direction, null, setup.referencePrice)
                    if (consumeAwaitingSignal()) {
                        getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("awaiting_signal", false).apply()
                        notifySignal(symbol, setup.direction, move, setup.volumeRatio, setup.referencePrice.toDouble(), setup.rsi8, setup.upperBand, setup.lowerBand)
                    }
                } catch (e: Exception) {
                    detector.allowRetry(symbol)
                    status = "Помилка 5m-сетапу $symbol: " + (e.message?.take(100) ?: e.javaClass.simpleName); updateServiceNotification()
                } finally { pendingEmaChecks.remove(symbol) }
            }
        })
    }

    private fun evaluateCachedSetup(symbol: String, candles: List<ScalpCandle>, move: Double) {
        try {
            val setup = M5BollingerStrategy.evaluate(candles)
            if (setup == null) {
                detector.allowRetry(symbol)
                status = "$symbol: немає підтвердження 5m (EMA200 + RSI8 + BB20/2)"
                updateServiceNotification()
                return
            }
            // Record each confirmed 5m setup for the 15-minute outcome table.
            // This is analytics only; it does not alter order sizing, direction, SL, or TP.
            journal.add(symbol, setup.direction, setup.referencePrice.toDouble(), move, setup.volumeRatio, System.currentTimeMillis())
            status = symbol + " " + setup.direction + ": 5m LIMIT MAKER • EMA200 / RSI8=" + String.format(java.util.Locale.US, "%.1f", setup.rsi8) +
                " • vol=" + String.format(java.util.Locale.US, "%.2f", setup.volumeRatio) + "x • SL " + fmt(setup.stopLoss.toDouble()) + " • TP " + fmt(setup.takeProfit.toDouble())
            updateServiceNotification()
            // Entry is GTC LIMIT at the BB edge; strategy and exchange-side TP/SL are unchanged.
            executeAutoTradeIfEnabled(symbol, setup.direction, null, setup.referencePrice)
            if (consumeAwaitingSignal()) {
                getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("awaiting_signal", false).apply()
                notifySignal(symbol, setup.direction, move, setup.volumeRatio, setup.referencePrice.toDouble(), setup.rsi8, setup.upperBand, setup.lowerBand)
            }
        } catch (e: Exception) {
            detector.allowRetry(symbol)
            status = "Помилка 5m-сетапу $symbol: " + (e.message?.take(100) ?: e.javaClass.simpleName)
            updateServiceNotification()
        } finally {
            pendingEmaChecks.remove(symbol)
        }
    }

    private fun executeAutoTradeIfEnabled(symbol: String, direction: String, stopLossOverride: java.math.BigDecimal? = null, limitPriceOverride: java.math.BigDecimal? = null) {
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        if (!prefs.getBoolean("auto_trade", false)) return
        if (!pendingExecutions.add(symbol)) return
        Thread({
            try {
                val credentials = ApiCredentialsStore(this).read()
                    ?: throw IllegalStateException("API-ключі відсутні. Автоторгівлю вимкнено.")
                val live = prefs.getBoolean("live_trading", false)
                val base = if (live) BinanceFuturesExecutor.LIVE_BASE_URL else BinanceFuturesExecutor.DEMO_BASE_URL
                val api = BinanceFuturesExecutor(credentials.first, credentials.second, base) { msg ->
                    android.util.Log.w("ImpulseAlertExecution", msg)
                }
                val budget = (prefs.getString("budget_usdt", "800") ?: "800").toBigDecimal()
                val manager = PositionManager(
                    executor = api,
                    parser = ExchangeInfoParser(),
                    risk = RiskManager(),
                    csv = TradeCsvLogger(this),
                    budgetUsdt = budget,
                    leverage = 10,
                    log = { msg -> android.util.Log.e("ImpulseAlertExecution", msg) }
                )
                val result = manager.executeSignal(symbol, direction, stopLossOverride, limitPriceOverride)
                status = "${if (live) "LIVE" else "DEMO"} виконано: $result"
                updateServiceNotification()
                notifyExecutionResult("${if (live) "LIVE" else "DEMO"}: $result")
            } catch (e: Exception) {
                status = "Автовхід $symbol $direction відхилено/помилка: ${e.message?.take(140) ?: e.javaClass.simpleName}"
                android.util.Log.e("ImpulseAlertExecution", status, e)
                updateServiceNotification()
                notifyExecutionResult(status)
            } finally {
                pendingExecutions.remove(symbol)
            }
        }, "ImpulseExecution-$symbol").start()
    }

    /**
     * Reconcile open positions for close detection only. Exchange-side fixed TP/SL are the only exits.
     * This watchdog never moves stops or closes positions.
     */
    /** Cancel only this bot's sibling exit orders after a position closes; preserve manual orders. */
    private fun cleanupBotExitOrders(api: BinanceFuturesExecutor, symbol: String) {
        try {
            val regular = api.openRegularOrders(symbol)
            for (i in 0 until regular.length()) {
                val order = regular.optJSONObject(i) ?: continue
                val clientId = order.optString("clientOrderId", order.optString("origClientOrderId", ""))
                val orderId = order.optLong("orderId", 0L)
                if (clientId.startsWith("IATP_") && orderId > 0L) {
                    runCatching { api.cancelRegularOrder(symbol, orderId) }
                        .onFailure { android.util.Log.e("ImpulseAlertCooldown", "Could not cancel stale bot LIMIT TP $symbol orderId=$orderId: ${it.message}") }
                }
            }
            val algos = api.openAlgoOrders(symbol)
            for (i in 0 until algos.length()) {
                val order = algos.optJSONObject(i) ?: continue
                val clientId = order.optString("clientAlgoId", "")
                val algoId = order.optLong("algoId", 0L)
                if ((clientId.startsWith("IAS_") || clientId.startsWith("IABE_") || clientId.startsWith("IATP_")) && algoId > 0L) {
                    runCatching { api.cancelAlgoOrder(symbol, algoId) }
                        .onFailure { android.util.Log.e("ImpulseAlertCooldown", "Could not cancel stale bot STOP $symbol algoId=$algoId: ${it.message}") }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ImpulseAlertCooldown", "Failed to clean stale bot exit orders for $symbol: ${e.message}")
        }
    }

    private fun checkBreakevenPositions() {
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        // Continue managing existing positions even if new automatic entries are switched off.
        if (!breakevenCheckRunning.compareAndSet(false, true)) return
        Thread({
            try {
                val credentials = ApiCredentialsStore(this).read() ?: return@Thread
                val live = prefs.getBoolean("live_trading", false)
                val base = if (live) BinanceFuturesExecutor.LIVE_BASE_URL else BinanceFuturesExecutor.DEMO_BASE_URL
                val api = BinanceFuturesExecutor(credentials.first, credentials.second, base) { msg ->
                    android.util.Log.w("ImpulseAlertBreakeven", msg)
                }
                val snapshots = api.positionSnapshots()
                val currentSymbols = snapshots.map { it.symbol }.toSet()
                val now = System.currentTimeMillis()
                if (positionSnapshotInitialized) {
                    val closedSymbols = knownOpenSymbols.toSet() - currentSymbols
                    for (closed in closedSymbols) {
                        // Determine the actual realized PnL for this position's lifetime.
                        // Cool down only for a negative realized PnL; profitable TP exits resume immediately.
                        val since = openSinceBySymbol.remove(closed) ?: (now - 10 * 60_000L)
                        try {
                            val realizedPnl = api.realizedPnlSince(closed, since)
                            if (realizedPnl != null) {
                                val csvLog = TradeCsvLogger(this)
                                csvLog.exit(closed, "", "", "", "", "", if (realizedPnl.signum() >= 0) "WIN" else "LOSS", realizedPnl.toPlainString())
                                statsLine = csvLog.statsLine()
                                updateServiceNotification()
                            }
                            when {
                                realizedPnl == null -> android.util.Log.w("ImpulseAlertCooldown", "$closed closed, but Binance has no realized-PnL record yet; no cooldown applied")
                                realizedPnl < java.math.BigDecimal.ZERO -> {
                                    symbolCooldownUntil[closed] = now + 7 * 60_000L
                                    android.util.Log.i("ImpulseAlertCooldown", "$closed realizedPnL=$realizedPnl USDT; apply 7-minute SL cooldown")
                                }
                                else -> {
                                    symbolCooldownUntil.remove(closed)
                                    android.util.Log.i("ImpulseAlertCooldown", "$closed realizedPnL=$realizedPnl USDT; profitable/non-loss exit, no cooldown")
                                }
                            }
                        } catch (pnlError: Exception) {
                            // Avoid falsely labeling a TP as an SL if the history endpoint is unavailable.
                            android.util.Log.e("ImpulseAlertCooldown", "Cannot determine realized PnL for $closed; no cooldown applied: ${pnlError.message}")
                        }
                        cleanupBotExitOrders(api, closed)
                    }
                } else {
                    positionSnapshotInitialized = true
                }
                for (symbol in currentSymbols) if (!openSinceBySymbol.containsKey(symbol)) openSinceBySymbol[symbol] = now
                knownOpenSymbols.clear()
                knownOpenSymbols.addAll(currentSymbols)
                symbolCooldownUntil.entries.removeIf { it.value <= now }
                // The watchdog only detects when exchange-side SL/TP has closed a position.
                // It deliberately does not modify the fixed stop or submit any exit order.
            } catch (e: Exception) {
                android.util.Log.e("ImpulseAlertBreakeven", "Breakeven scan failed: ${e.message}", e)
            } finally {
                breakevenCheckRunning.set(false)
            }
        }, "ImpulseBreakevenManager").start()
    }

    private fun notifyExecutionResult(message: String) {
        val notification = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_impulse)
            .setContentTitle("ImpulseAlert • виконання")
            .setContentText(message.take(220))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        try { NotificationManagerCompat.from(this).notify(("execution" + System.currentTimeMillis()).hashCode(), notification) }
        catch (_: SecurityException) { }
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val alpha = 2.0 / (period + 1.0)
        var result = values.first()
        for (i in 1 until values.size) result += alpha * (values[i] - result)
        return result
    }

    private fun fmt(value: Double): String = String.format(java.util.Locale.US, "%.8f", value)

    private fun notifySignal(symbol: String, dir: String, move: Double, vol: Double, price: Double, rsi8: Double, upperBand: Double, lowerBand: Double) {
        val sign = if (dir == "LONG") "+" else "-"
        val coin = symbol.removeSuffix("USDT")
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_impulse)
            .setContentTitle("$coin — ВХІД $dir")
            .setContentText("Імпульс $sign${"%.2f".format(move)}% • RSI8: ${String.format(java.util.Locale.US, "%.1f", rsi8)} • BB upper/lower: ${fmt(upperBand)}/${fmt(lowerBand)} • ціна $price • SL/TP 0.4%/1.2%")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        try {
            NotificationManagerCompat.from(this).notify(symbol.hashCode(), n)
        } catch (_: SecurityException) { /* немає дозволу на сповіщення */ }
    }
}
