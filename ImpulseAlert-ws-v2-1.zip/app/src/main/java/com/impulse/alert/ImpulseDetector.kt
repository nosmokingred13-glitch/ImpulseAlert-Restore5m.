package com.impulse.alert

/**
 * Rate-limited scan trigger for liquid Binance Futures USDT pairs.
 * Actual direction and entry conditions are determined exclusively from closed 5m klines
 * by M5BollingerStrategy; miniTicker direction is only informational.
 */
class ImpulseDetector(
    private val scanIntervalMs: Long = 15_000L,
    private val cooldownMs: Long = 2 * 60_000L,
    private val warmupMs: Long = 15_000L,
    private val minQuoteVol24h: Double = 0.0,
    private val onSignal: (symbol: String, direction: String, movePct: Double, volRatio: Double, price: Double) -> Unit
) {
    private class Tick(val t: Long, val p: Double, val q: Double)

    private val hist = HashMap<String, ArrayDeque<Tick>>()
    private val lastSignal = HashMap<String, Long>()
    private val lastScan = HashMap<String, Long>()

    @Synchronized
    fun clear() {
        hist.clear()
        lastSignal.clear()
        lastScan.clear()
    }

    /** Start a fresh one-shot scan without reusing the previous scan's price history. */
    @Synchronized
    fun resetForNewScan() {
        hist.clear()
        lastSignal.clear()
        lastScan.clear()
    }

    /** Retry the 5m strategy after a scan did not produce a valid setup. */
    @Synchronized
    fun allowRetry(symbol: String) {
        lastSignal.remove(symbol)
    }

    @Synchronized
    fun onTick(symbol: String, price: Double, quoteVol24h: Double, now: Long) {
        if (!price.isFinite() || price <= 0.0 || !quoteVol24h.isFinite() || quoteVol24h < minQuoteVol24h) {
            hist.remove(symbol)
            return
        }
        val ticks = hist.getOrPut(symbol) { ArrayDeque() }
        ticks.addLast(Tick(now, price, quoteVol24h))
        while (ticks.isNotEmpty() && now - ticks.first().t > 90_000L) ticks.removeFirst()
        if (ticks.isEmpty() || now - ticks.first().t < warmupMs) return
        if (now - (lastSignal[symbol] ?: 0L) < cooldownMs) return
        if (now - (lastScan[symbol] ?: 0L) < scanIntervalMs) return
        lastScan[symbol] = now

        val first = ticks.first()
        val elapsed = ((now - first.t).coerceAtLeast(1L)) / 1000.0
        val movePct = kotlin.math.abs((price - first.p) / first.p * 100.0)
        val avgRate = quoteVol24h / 86_400.0
        val recentRate = kotlin.math.max(0.0, quoteVol24h - first.q) / elapsed
        val volRatio = if (avgRate > 0.0) (recentRate + avgRate) / avgRate else 0.0
        val direction = if (price >= first.p) "LONG" else "SHORT"

        // This merely wakes the REST strategy check; it is not an entry signal.
        lastSignal[symbol] = now
        onSignal(symbol, direction, movePct, volRatio, price)
    }
}
