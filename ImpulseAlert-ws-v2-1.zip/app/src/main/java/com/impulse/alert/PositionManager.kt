package com.impulse.alert

import org.json.JSONObject
import java.math.BigDecimal
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

private object ExecutionGuard {
    val lock = Any()
}

class PositionManager(
    private val executor: BinanceFuturesExecutor,
    private val parser: ExchangeInfoParser,
    private val risk: RiskManager,
    private val csv: TradeCsvLogger,
    private val budgetUsdt: BigDecimal,
    private val leverage: Int = 10,
    private val log: (String) -> Unit = {}
) {
    private val activeSymbols = ConcurrentHashMap.newKeySet<String>()

    fun executeSignal(symbolRaw: String, directionRaw: String, stopLossOverride: BigDecimal? = null, limitPriceOverride: BigDecimal? = null): String = synchronized(ExecutionGuard.lock) {
        val symbol = symbolRaw.uppercase()
        val direction = directionRaw.uppercase()
        require(direction == "LONG" || direction == "SHORT") { "Invalid signal direction" }
        if (!activeSymbols.add(symbol)) throw IllegalStateException("An order for $symbol is already being processed")
        try {
            // Exchange-side closePosition SL and TP_MARKET are used only in One-way position mode.
            executor.requireOneWayPositionMode()
            val available = executor.availableUsdt()
            val walletBalance = executor.walletBalanceUsdt()
            val maxPositions = risk.maxConcurrentPositions(walletBalance)
            val openPositions = executor.openPositions()
            if (symbol in openPositions) {
                throw IllegalStateException("$symbol already has an open Futures position; duplicate entry blocked")
            }
            if (openPositions.size >= maxPositions) {
                throw IllegalStateException("Open-position limit reached: ${openPositions.size}/$maxPositions for wallet balance $walletBalance USDT")
            }
            val selectedMargin = risk.marginForBalance(walletBalance).min(budgetUsdt).min(available)
            val allowedNotional = risk.validateBudget(selectedMargin, available, leverage)
            log("Margin ladder: wallet=$walletBalance USDT, available=$available USDT, margin=$selectedMargin USDT, leverage=x$leverage, open positions=${openPositions.size}/$maxPositions, targetNotional≈$allowedNotional USDT")

            // Preflight exchangeInfo filters and the strategy's Bollinger edge before a GTC LIMIT.
            val rules = parser.parse(executor.exchangeInfoJson(), symbol)
            val referencePrice = limitPriceOverride ?: executor.price(symbol)
            require(referencePrice > BigDecimal.ZERO) { "Invalid limit entry price for $symbol" }
            if (executor.openRegularOrders(symbol).length() > 0) {
                throw IllegalStateException("$symbol already has an open order; duplicate/pending entry blocked")
            }
            // M5 structure stops vary in width. Cap the notional so the planned stop loss
            // is at most 1% of wallet balance; if exchange minimums exceed this, skip the trade.
            val riskCappedNotional = if (stopLossOverride != null) {
                require(if (direction == "LONG") stopLossOverride < referencePrice else stopLossOverride > referencePrice) {
                    "Structure/ATR stop is on the wrong side of current price; trade rejected"
                }
                val stopFraction = referencePrice.subtract(stopLossOverride).abs()
                    .divide(referencePrice, 12, java.math.RoundingMode.HALF_UP)
                // Reject mismatched-symbol/scale stops (e.g. entry 501.59 with stop 10.68).
                // A structure stop wider than 10% is not an acceptable scalp setup.
                require(stopFraction >= BigDecimal("0.0001") && stopFraction <= BigDecimal("0.10")) {
                    "Structure/ATR stop distance exceeds allowed bounds; refusing entry"
                }
                val maxRiskUsdt = walletBalance.multiply(BigDecimal("0.04"))
                val riskNotional = maxRiskUsdt.divide(stopFraction, 12, java.math.RoundingMode.DOWN)
                allowedNotional.min(riskNotional)
            } else allowedNotional
            require(riskCappedNotional > BigDecimal.ZERO) { "Risk sizing leaves no allowed notional" }
            log("5m risk cap: max loss≈4% wallet; allowed notional=$riskCappedNotional USDT (before exchange minimums)")
            val qty = try {
                parser.normalizeQuantity(rules, referencePrice, riskCappedNotional)
            } catch (e: IllegalArgumentException) {
                log("Signal skipped before order submission: ${e.message}")
                throw e
            }

            executor.setLeverage(symbol, leverage)
            val clientId = "IAE_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
            val limitPrice = parser.formatEntryPrice(rules, referencePrice, direction)
            log("LIMIT_ENTRY_SUBMIT $symbol $direction price=$limitPrice qty=$qty type=LIMIT timeInForce=GTC")
            val entry = executor.makerLimitEntry(symbol, if (direction == "LONG") "BUY" else "SELL", qty.toPlainString(), limitPrice, clientId)
            // Parse the exchange response defensively. A malformed/unexpected response must
            // never leave a possible fill outside the protection-failure recovery path.
            val filled = entry.executedQty.toBigDecimalOrNull() ?: BigDecimal.ZERO
            var fillPrice = entry.avgPrice.toBigDecimalOrNull() ?: BigDecimal.ZERO
            if (filled > BigDecimal.ZERO && fillPrice <= BigDecimal.ZERO) {
                // Last-resort reconciliation: Binance's live positionRisk entryPrice may be
                // populated even when the immediate MARKET RESULT avgPrice is zero.
                try {
                    val exchangeEntryPrice = executor.positionEntryPrice(symbol)
                    if (exchangeEntryPrice > BigDecimal.ZERO) {
                        fillPrice = exchangeEntryPrice
                        log("LIMIT_FILL_POSITION_PRICE_FALLBACK $symbol orderId=${entry.orderId} entryPrice=$fillPrice")
                    }
                } catch (priceError: Exception) {
                    log("LIMIT_FILL_POSITION_PRICE_LOOKUP_FAILED $symbol orderId=${entry.orderId}: ${priceError.message}")
                }
            }
            if (filled <= BigDecimal.ZERO) {
                csv.error(symbol, direction, "GTC LIMIT entry not filled: status=${entry.status}; qty=${entry.executedQty}; avgPrice=${entry.avgPrice}")
                throw IllegalStateException("GTC LIMIT entry has no executed quantity; no position close was submitted (status=${entry.status})")
            }
            if (fillPrice <= BigDecimal.ZERO) {
                // LIMIT fills execute at the limit price or better. Prefer exchange-reported position entry;
                // if Binance's response is temporarily incomplete, use the submitted LIMIT as a last-resort
                // reference to install protection instead of panic-closing the position at MARKET.
                fillPrice = limitPrice.toBigDecimal()
                log("CRITICAL_ENTRY_PRICE_FALLBACK $symbol orderId=${entry.orderId} using LIMIT price=$fillPrice to place exchange-side protection")
            }

            val exitSide = if (direction == "LONG") "SELL" else "BUY"

            var stopAlgoId: Long? = null
            var takeAlgoId: Long? = null
            try {
                // Fixed SL/TP levels are based on the confirmed LIMIT fill. The exchange owns both exits.
                val levels = risk.levels(fillPrice, direction)
                val stop = parser.formatPrice(rules, levels.stopLoss, direction, true)
                val take = parser.formatPrice(rules, levels.takeProfit, direction, false)
                val stopClientId = "IAS_${UUID.randomUUID().toString().take(12)}"
                val takeClientId = "IATP_${UUID.randomUUID().toString().take(20)}"
                log("PROTECTION_SUBMIT $symbol tickSize=${rules.tickSize} STOP_MARKET=$stop TAKE_PROFIT_MARKET=$take closePosition=true")

                val stopFuture = java.util.concurrent.CompletableFuture.supplyAsync {
                    runCatching { executor.conditionalCloseAll(symbol, exitSide, "STOP_MARKET", stop, stopClientId) }
                }
                val takeFuture = java.util.concurrent.CompletableFuture.supplyAsync {
                    runCatching { executor.conditionalCloseAll(symbol, exitSide, "TAKE_PROFIT_MARKET", take, takeClientId) }
                }
                val stopResult = stopFuture.get()
                val takeResult = takeFuture.get()

                stopResult.onFailure {
                    log("BINANCE_SL_REJECTED $symbol type=STOP_MARKET price=$stop error=${it.javaClass.simpleName}: ${it.message}")
                }
                takeResult.onFailure {
                    log("BINANCE_TP_REJECTED $symbol type=TAKE_PROFIT_MARKET trigger=$take error=${it.javaClass.simpleName}: ${it.message}")
                }

                stopResult.getOrNull()?.let { response ->
                    if (response.optLong("algoId", 0L) > 0L) stopAlgoId = response.optLong("algoId")
                }
                takeResult.getOrNull()?.let { response ->
                    if (response.optLong("algoId", 0L) > 0L) takeAlgoId = response.optLong("algoId")
                }
                if (stopResult.isFailure || takeResult.isFailure) {
                    throw IllegalStateException(
                        "Protection submission failed for $symbol; " +
                            "SL=${stopResult.exceptionOrNull()?.message ?: "accepted"}; " +
                            "TP=${takeResult.exceptionOrNull()?.message ?: "accepted"}"
                    )
                }

                val stopResponse = stopResult.getOrThrow()
                if (stopResponse.optLong("algoId", 0L) <= 0L ||
                    stopResponse.optString("algoStatus") !in setOf("NEW", "WORKING")) {
                    throw IllegalStateException("Binance did not acknowledge active STOP_MARKET: $stopResponse")
                }
                stopAlgoId = stopResponse.optLong("algoId")

                val takeResponse = takeResult.getOrThrow()
                val returnedAlgoId = takeResponse.optLong("algoId", 0L)
                if (returnedAlgoId <= 0L || takeResponse.optString("algoStatus") !in setOf("NEW", "WORKING")) {
                    throw IllegalStateException("Binance did not acknowledge active TAKE_PROFIT_MARKET: $takeResponse")
                }
                takeAlgoId = returnedAlgoId

                val confirmedStop = executor.queryAlgoOrder(symbol, stopAlgoId!!)
                val confirmedStopPrice = confirmedStop.optString("triggerPrice", "0").toBigDecimalOrNull()
                if (confirmedStop.optString("algoStatus") !in setOf("NEW", "WORKING") ||
                    confirmedStop.optString("symbol") != symbol ||
                    confirmedStop.optString("side") != exitSide ||
                    confirmedStop.optString("orderType", confirmedStop.optString("type")) != "STOP_MARKET" ||
                    !confirmedStop.optBoolean("closePosition", false) ||
                    confirmedStopPrice?.compareTo(stop.toBigDecimal()) != 0) {
                    throw IllegalStateException("Binance did not confirm requested STOP_MARKET: $confirmedStop")
                }

                val confirmedTake = executor.queryAlgoOrder(symbol, takeAlgoId!!)
                val confirmedTakePrice = confirmedTake.optString("triggerPrice", "0").toBigDecimalOrNull()
                if (confirmedTake.optLong("algoId", 0L) != returnedAlgoId ||
                    confirmedTake.optString("symbol") != symbol ||
                    confirmedTake.optString("side") != exitSide ||
                    confirmedTake.optString("orderType", confirmedTake.optString("type")) != "TAKE_PROFIT_MARKET" ||
                    !confirmedTake.optBoolean("closePosition", false) ||
                    confirmedTakePrice?.compareTo(take.toBigDecimal()) != 0 ||
                    confirmedTake.optString("algoStatus") !in setOf("NEW", "WORKING")) {
                    throw IllegalStateException("Binance did not confirm requested TAKE_PROFIT_MARKET: $confirmedTake")
                }

                csv.entry(symbol, direction, fillPrice.toPlainString(), filled.toPlainString(), stop, take)
                log("PROTECTION_ACCEPTED $symbol SL=STOP_MARKET algoId=$stopAlgoId trigger=$stop; TP=TAKE_PROFIT_MARKET algoId=$takeAlgoId trigger=$take closePosition=true")
                return@synchronized "$symbol $direction FILLED qty=$filled entry=$fillPrice SL=$stop TP=$take"
            } catch (e: Exception) {
                csv.error(symbol, direction, "Protection verification/submission issue: ${e.javaClass.simpleName}: ${e.message}")
                // Never send a MARKET close as an error fallback. Preserve any accepted exchange-side
                // protections and raise a clear alert so the user can inspect Binance Futures.
                log("CRITICAL_PROTECTION_ISSUE $symbol SL_algoId=${stopAlgoId ?: "none"} TP_algoId=${takeAlgoId ?: "none"}; MARKET close intentionally disabled; inspect exchange-side exits immediately: ${e.message}")
                throw e
            }
        } finally {
            activeSymbols.remove(symbol)
        }
    }
}
