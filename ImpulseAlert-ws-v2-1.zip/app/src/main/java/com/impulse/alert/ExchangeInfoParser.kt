package com.impulse.alert

import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode

data class SymbolRules(
    val symbol: String, val status: String, val quantityStep: BigDecimal,
    val minQty: BigDecimal, val maxQty: BigDecimal, val minNotional: BigDecimal, val tickSize: BigDecimal
)

class ExchangeInfoParser {
    fun parse(json: JSONObject, symbol: String): SymbolRules {
        val symbols = json.optJSONArray("symbols") ?: throw IllegalArgumentException("exchangeInfo has no symbols")
        for (i in 0 until symbols.length()) {
            val row = symbols.getJSONObject(i)
            if (!row.optString("symbol").equals(symbol, true)) continue

            var lotStep = BigDecimal.ZERO
            var lotMinQty = BigDecimal.ZERO
            var lotMaxQty = BigDecimal.ZERO
            var marketStep = BigDecimal.ZERO
            var marketMinQty = BigDecimal.ZERO
            var marketMaxQty = BigDecimal.ZERO
            var minNotional = BigDecimal.ZERO
            var tick = BigDecimal.ZERO
            val filters = row.optJSONArray("filters")
                ?: throw IllegalArgumentException("Exchange filters are missing for $symbol")

            for (j in 0 until filters.length()) {
                val f = filters.getJSONObject(j)
                when (f.optString("filterType")) {
                    "LOT_SIZE" -> {
                        lotStep = BigDecimal(f.optString("stepSize", "0"))
                        lotMinQty = BigDecimal(f.optString("minQty", "0"))
                        lotMaxQty = BigDecimal(f.optString("maxQty", "0"))
                    }
                    "MARKET_LOT_SIZE" -> {
                        marketStep = BigDecimal(f.optString("stepSize", "0"))
                        marketMinQty = BigDecimal(f.optString("minQty", "0"))
                        marketMaxQty = BigDecimal(f.optString("maxQty", "0"))
                    }
                    "MIN_NOTIONAL" -> {
                        val appliesToMarket = f.optBoolean("applyToMarket", true)
                        // USDⓈ-M Futures exchangeInfo may expose MIN_NOTIONAL as "notional", not "minNotional".
                        // Read both keys or preflight misses the exchange minimum and Binance rejects the order.
                        val n = BigDecimal(f.optString("minNotional", f.optString("notional", "0")))
                        if (appliesToMarket && n > minNotional) minNotional = n
                    }
                    "NOTIONAL" -> {
                        val appliesMinToMarket = f.optBoolean("applyMinToMarket", true)
                        val n = BigDecimal(f.optString("minNotional", f.optString("notional", "0")))
                        if (appliesMinToMarket && n > minNotional) minNotional = n
                    }
                    "PRICE_FILTER" -> tick = BigDecimal(f.optString("tickSize", "0"))
                }
            }

            if (row.optString("status") != "TRADING") {
                throw IllegalArgumentException("$symbol is not TRADING")
            }

            // Entry orders are LIMIT-only: use LOT_SIZE filters, not MARKET_LOT_SIZE.
            val step = lotStep
            val minQty = lotMinQty
            val maxQty = lotMaxQty

            if (step <= BigDecimal.ZERO || minQty <= BigDecimal.ZERO || tick <= BigDecimal.ZERO) {
                throw IllegalArgumentException("Required quantity/price filters are missing or invalid for $symbol")
            }
            return SymbolRules(symbol, row.optString("status"), step, minQty, maxQty, minNotional, tick)
        }
        throw IllegalArgumentException("Symbol $symbol not found in exchangeInfo")
    }

    /**
     * Computes a quantity that stays within the configured notional budget.
     * It never rounds quantity up to force an order through an exchange minimum.
     */
    fun normalizeQuantity(rules: SymbolRules, price: BigDecimal, maxNotional: BigDecimal): BigDecimal {
        require(price > BigDecimal.ZERO) { "Invalid reference price for ${rules.symbol}: $price" }
        require(maxNotional > BigDecimal.ZERO) { "Allowed order notional must be positive" }

        if (rules.minNotional > maxNotional) {
            throw IllegalArgumentException(
                "${rules.symbol} skipped: Binance market minimum is ${rules.minNotional} USDT, " +
                    "but this balance tier allows only ${maxNotional} USDT notional"
            )
        }

        val raw = maxNotional.divide(price, 18, RoundingMode.DOWN)
        var qty = raw.divide(rules.quantityStep, 0, RoundingMode.DOWN)
            .multiply(rules.quantityStep).stripTrailingZeros()

        if (rules.maxQty > BigDecimal.ZERO && qty > rules.maxQty) {
            qty = rules.maxQty.divide(rules.quantityStep, 0, RoundingMode.DOWN)
                .multiply(rules.quantityStep).stripTrailingZeros()
        }

        if (qty <= BigDecimal.ZERO || qty < rules.minQty) {
            val minStepQty = rules.minQty.divide(rules.quantityStep, 0, RoundingMode.UP)
                .multiply(rules.quantityStep)
            val minimumQtyNotional = minStepQty.multiply(price)
            throw IllegalArgumentException(
                "${rules.symbol} skipped: calculated quantity ${qty.toPlainString()} is below Binance minimum " +
                    "${minStepQty.stripTrailingZeros().toPlainString()}; minimum quantity would cost about " +
                    "${minimumQtyNotional.setScale(8, RoundingMode.UP).stripTrailingZeros().toPlainString()} USDT, " +
                    "above allowed ${maxNotional} USDT"
            )
        }

        val actualNotional = qty.multiply(price)
        if (actualNotional < rules.minNotional) {
            throw IllegalArgumentException(
                "${rules.symbol} skipped: after Binance step-size rounding, order notional is " +
                    "${actualNotional.setScale(8, RoundingMode.DOWN).stripTrailingZeros().toPlainString()} USDT, " +
                    "below the exchange minimum ${rules.minNotional} USDT; allowed budget is ${maxNotional} USDT"
            )
        }
        return qty
    }

    /** Round a maker entry away from crossing the spread: BUY down, SELL up. */
    fun formatEntryPrice(rules: SymbolRules, price: BigDecimal, direction: String): String {
        require(price > BigDecimal.ZERO)
        require(direction == "LONG" || direction == "SHORT")
        require(rules.tickSize > BigDecimal.ZERO)
        val mode = if (direction == "LONG") RoundingMode.DOWN else RoundingMode.UP
        val formatted = price.divide(rules.tickSize, 0, mode).multiply(rules.tickSize).stripTrailingZeros()
        require(formatted > BigDecimal.ZERO)
        return formatted.toPlainString()
    }

    /**
     * Formats a price using the exact Binance PRICE_FILTER tickSize returned by exchangeInfo.
     * Direction-aware rounding keeps protective prices on the intended side without using Double/round().
     */
    fun formatPrice(rules: SymbolRules, price: BigDecimal, direction: String, isStop: Boolean): String {
        require(price > BigDecimal.ZERO) { "Invalid price for ${rules.symbol}: $price" }
        require(rules.tickSize > BigDecimal.ZERO) {
            "Binance PRICE_FILTER tickSize is missing/invalid for ${rules.symbol}"
        }
        require(direction == "LONG" || direction == "SHORT") { "Invalid direction for price formatting: $direction" }

        val mode = when {
            direction == "LONG" && isStop -> RoundingMode.DOWN
            direction == "LONG" && !isStop -> RoundingMode.UP
            direction == "SHORT" && isStop -> RoundingMode.UP
            else -> RoundingMode.DOWN
        }
        val formatted = price.divide(rules.tickSize, 0, mode)
            .multiply(rules.tickSize)
            .stripTrailingZeros()
        require(formatted > BigDecimal.ZERO) {
            "Price rounded to zero by Binance tickSize for ${rules.symbol}: price=$price tickSize=${rules.tickSize}"
        }
        // Guard against accidental future changes that could produce a value outside PRICE_FILTER.
        require(formatted.remainder(rules.tickSize).compareTo(BigDecimal.ZERO) == 0) {
            "Formatted price $formatted violates Binance tickSize ${rules.tickSize} for ${rules.symbol}"
        }
        return formatted.toPlainString()
    }
}
