package com.impulse.alert

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Журнал сигналів. Для кожного сигналу фіксує ціну входу і далі 15 хвилин відстежує:
 *  - результат через 1, 5 і 15 хв (у % у бік сигналу, без комісій);
 *  - максимальний плюс (max_fav) і максимальну просадку (max_adv);
 *  - що було першим: ціль +TP% чи стоп -SL%  (outcome = TP / SL / NONE).
 * Завершені записи дописуються у signals.csv.
 */
class SignalJournal(private val file: File) {

    private class Pending(
        val symbol: String, val dir: String, val t0: Long,
        val entry: Double, val move: Double, val vol: Double
    ) {
        var r1: Double? = null
        var r3: Double? = null
        var r5: Double? = null
        var r15: Double? = null
        var maxFav = 0.0
        var maxAdv = 0.0
        var outcome = ""
        var outcome1 = ""
        var outcome2 = ""
        var outcome3 = ""
    }

    private val pending = HashMap<String, MutableList<Pending>>()

    @Synchronized
    fun add(symbol: String, dir: String, price: Double, move: Double, vol: Double, now: Long) {
        pending.getOrPut(symbol) { mutableListOf() }.add(Pending(symbol, dir, now, price, move, vol))
        tracking = pending.values.sumOf { it.size }
    }

    @Synchronized
    fun onTick(symbol: String, price: Double, now: Long) {
        val list = pending[symbol] ?: return
        val it = list.iterator()
        while (it.hasNext()) {
            val s = it.next()
            val r = if (s.dir == "LONG") (price - s.entry) / s.entry * 100.0
                    else (s.entry - price) / s.entry * 100.0
            if (r > s.maxFav) s.maxFav = r
            if (-r > s.maxAdv) s.maxAdv = -r
            if (s.outcome.isEmpty()) {
                if (s.maxFav >= TP) s.outcome = "TP"
                else if (s.maxAdv >= SL) s.outcome = "SL"
            }
            // Shadow-test alternative targets against the fixed 0.4% price stop.
            if (s.outcome1.isEmpty()) s.outcome1 = when {
                r >= 1.2 -> "TP"
                r <= -SL -> "SL"
                else -> ""
            }
            if (s.outcome2.isEmpty()) s.outcome2 = when {
                r >= 1.5 -> "TP"
                r <= -SL -> "SL"
                else -> ""
            }
            if (s.outcome3.isEmpty()) s.outcome3 = when {
                r >= 2.0 -> "TP"
                r <= -SL -> "SL"
                else -> ""
            }
            val age = now - s.t0
            if (age >= 60_000 && s.r1 == null) s.r1 = r
            if (age >= 180_000 && s.r3 == null) s.r3 = r
            if (age >= 300_000 && s.r5 == null) s.r5 = r
            if (age >= 900_000) {
                s.r15 = r
                write(s)
                it.remove()
            }
        }
        if (list.isEmpty()) pending.remove(symbol)
        tracking = pending.values.sumOf { it.size }
    }

    private fun write(s: Pending) {
        try {
            val header = "time,symbol,dir,entry,move_pct,vol_ratio,r1,r5,r15,max_fav,max_adv,outcome,r3,outcome_tp12_sl04,outcome_tp15_sl04,outcome_tp20_sl04"
            if (!file.exists() || file.length() == 0L) {
                file.writeText(header + "\n")
            } else {
                // Upgrade an older journal without discarding any existing rows.
                val old = file.readLines()
                if (old.isNotEmpty() && !old[0].contains("outcome_tp20_sl04")) {
                    // Preserve historical measurements, but clear old shadow outcomes:
                    // they used different TP/SL assumptions and must not be relabeled.
                    val migrated = old.drop(1).map { row ->
                        val cols = row.split(",")
                        (cols.take(11) + listOf("") + listOf(cols.getOrElse(12) { "" }) + listOf("", "", "")).joinToString(",")
                    }
                    file.writeText(header + "\n" + migrated.joinToString("\n") + if (migrated.isEmpty()) "" else "\n")
                }
            }
            val f = { d: Double? -> if (d == null) "" else String.format(Locale.US, "%.3f", d) }
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(s.t0))
            file.appendText(
                "$time,${s.symbol},${s.dir},${s.entry},${f(s.move)},${f(s.vol)}," +
                "${f(s.r1)},${f(s.r5)},${f(s.r15)},${f(s.maxFav)},${f(s.maxAdv)}," +
                "${s.outcome.ifEmpty { "NONE" }},${f(s.r3)}," +
                "${s.outcome1.ifEmpty { "NONE" }},${s.outcome2.ifEmpty { "NONE" }},${s.outcome3.ifEmpty { "NONE" }}\n"
            )
        } catch (_: Exception) { }
    }

    companion object {
        const val TP = 1.2  // фіксований тейк-профіт, %
        const val SL = 0.4  // фіксований стоп-лос, %
        @Volatile var tracking = 0

        fun statsText(file: File): String {
            if (!file.exists()) return "Журнал порожній.\nСигнали з'являться тут через 15 хв після першого спрацювання."
            // Migrate immediately when opening statistics, not only after the next completed signal.
            // Historical TP/SL shadow outcomes used old thresholds, so clear those columns.
            val current = file.readLines()
            if (current.isNotEmpty() && !current[0].contains("outcome_tp20_sl04")) {
                val newHeader = "time,symbol,dir,entry,move_pct,vol_ratio,r1,r5,r15,max_fav,max_adv,outcome,r3,outcome_tp12_sl04,outcome_tp15_sl04,outcome_tp20_sl04"
                val migrated = current.drop(1).map { row ->
                    val cols = row.split(",")
                    (cols.take(11) + listOf("") + listOf(cols.getOrElse(12) { "" }) + listOf("", "", "")).joinToString(",")
                }
                file.writeText(newHeader + "\n" + migrated.joinToString("\n") + if (migrated.isEmpty()) "" else "\n")
            }
            val rows = file.readLines().drop(1).mapNotNull { line ->
                val c = line.split(",")
                if (c.size < 12) null else try {
                    doubleArrayOf(
                        c[6].toDoubleOrNull() ?: Double.NaN,
                        c.getOrNull(12)?.toDoubleOrNull() ?: Double.NaN,
                        c[7].toDoubleOrNull() ?: Double.NaN,
                        c[8].toDoubleOrNull() ?: Double.NaN,
                        c[9].toDouble(), c[10].toDouble()
                    ) to c[11]
                } catch (_: Exception) { null }
            }
            val n = rows.size
            if (n == 0) return "Журнал порожній."
            val targetRows = file.readLines().drop(1).mapNotNull { line ->
                val cols = line.split(",")
                if (cols.size < 16) null else cols.subList(13, 16)
            }
            fun modelStats(index: Int): String {
                val evaluated = targetRows.map { it[index] }.filter { it == "TP" || it == "SL" || it == "NONE" }
                if (evaluated.isEmpty()) return "ще немає даних"
                val tpCount = evaluated.count { it == "TP" }
                val slCount = evaluated.count { it == "SL" }
                val noneCount = evaluated.count { it == "NONE" }
                return "TP ${tpCount * 100 / evaluated.size}% • SL ${slCount * 100 / evaluated.size}% • без цілі/стопа ${noneCount * 100 / evaluated.size}% (n=${evaluated.size})"
            }
            fun pct(x: Int) = String.format(Locale.US, "%.0f%%", x * 100.0 / n)
            fun avg(i: Int): String {
                val v = rows.map { it.first[i] }.filter { !it.isNaN() }
                return if (v.isEmpty()) "-" else String.format(Locale.US, "%+.2f%%", v.average())
            }
            val reach2 = rows.count { it.first[4] >= 1.2 }
            val reach3 = rows.count { it.first[4] >= 2.0 }
            val tp = rows.count { it.second == "TP" }
            val sl = rows.count { it.second == "SL" }
            val none = n - tp - sl
            val avgFav = String.format(Locale.US, "%.2f%%", rows.map { it.first[4] }.average())
            val avgAdv = String.format(Locale.US, "%.2f%%", rows.map { it.first[5] }.average())
            return "Завершених сигналів: $n\n" +
                "Параметри: TP +1.2% • SL -0.4%\n" +
                "Дійшли до +1.2%: ${pct(reach2)} • до +2.0%: ${pct(reach3)}\n" +
                "Першим було +${String.format(Locale.US, "%.1f", TP)}%: ${pct(tp)}\n" +
                "Першим було -${String.format(Locale.US, "%.1f", SL)}% (стоп): ${pct(sl)}\n" +
                "Тест виходів (модель, SL -0.4%): TP +1.2% — ${modelStats(0)}\nTP +1.5% — ${modelStats(1)}\nTP +2.0% — ${modelStats(2)}\n" +
                "Ні те, ні інше за 15 хв: ${pct(none)}\n" +
                "Середня зміна після входу:\n 1хв ${avg(0)} • 3хв ${avg(1)} • 5хв ${avg(2)} • 15хв ${avg(3)}\n" +
                "Сер. макс. плюс $avgFav • макс. мінус $avgAdv\n" +
                "(без комісій і проковзування)"
        }
    }
}
