package com.impulse.alert

import org.json.JSONArray
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.sqrt

data class ScalpCandle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val quoteVolume: Double,
    val closeTime: Long = 0L
)

data class ScalpSetup(
    val direction: String,
    val referencePrice: BigDecimal,
    val stopLoss: BigDecimal,
    val takeProfit: BigDecimal,
    val rsi8: Double,
    val upperBand: Double,
    val lowerBand: Double,
    val volumeRatio: Double
)

object M5BollingerStrategy {
    const val TIMEFRAME = "5m"
    private const val RSI_PERIOD = 8
    private const val BB_PERIOD = 20
    private const val BB_DEVIATIONS = 2.0
    private const val EMA_PERIOD = 200
    private const val STOP_PCT = 0.004
    private const val TARGET_PCT = 0.012

    fun parseCandles(rows: JSONArray): List<ScalpCandle> {
        val out = ArrayList<ScalpCandle>()
        for (i in 0 until rows.length()) {
            val row = rows.optJSONArray(i) ?: continue
            if (row.length() < 8) continue
            val candle = ScalpCandle(
                open = row.optString(1).toDoubleOrNull() ?: continue,
                high = row.optString(2).toDoubleOrNull() ?: continue,
                low = row.optString(3).toDoubleOrNull() ?: continue,
                close = row.optString(4).toDoubleOrNull() ?: continue,
                quoteVolume = row.optString(7).toDoubleOrNull() ?: continue,
                closeTime = row.optString(6).toLongOrNull() ?: continue
            )
            if (candle.open > 0 && candle.low > 0 && candle.high >= candle.low &&
                candle.close > 0 && candle.quoteVolume >= 0) out.add(candle)
        }
        return out
    }

    /** Evaluate only fully closed 5m candles: EMA200 + RSI8 + Bollinger Bands (20, 2). */
    fun evaluate(candles: List<ScalpCandle>, nowMs: Long = System.currentTimeMillis()): ScalpSetup? {
        val closed = candles.filter { it.closeTime > 0L && it.closeTime < nowMs }
        if (closed.size < EMA_PERIOD + 1) return null
        val closes = closed.map { it.close }
        val last = closed.last()
        val ema200 = ema(closes, EMA_PERIOD)
        val window = closes.takeLast(BB_PERIOD)
        val middle = window.average()
        val variance = window.sumOf { (it - middle) * (it - middle) } / BB_PERIOD
        val deviation = sqrt(variance)
        val upper = middle + BB_DEVIATIONS * deviation
        val lower = middle - BB_DEVIATIONS * deviation
        val rsi8 = rsi(closes, RSI_PERIOD)
        val avgQuoteVolume = closed.dropLast(1).takeLast(20).map { it.quoteVolume }.average()
        val volumeRatio = if (avgQuoteVolume > 0.0) last.quoteVolume / avgQuoteVolume else 0.0

        val direction = when {
            last.close > ema200 && rsi8 < 30.0 && last.low <= lower -> "LONG"
            last.close < ema200 && rsi8 > 70.0 && last.high >= upper -> "SHORT"
            else -> return null
        }
        val entry = if (direction == "LONG") lower else upper
        if (!entry.isFinite() || entry <= 0.0) return null
        val sl = if (direction == "LONG") entry * (1.0 - STOP_PCT) else entry * (1.0 + STOP_PCT)
        val tp = if (direction == "LONG") entry * (1.0 + TARGET_PCT) else entry * (1.0 - TARGET_PCT)
        return ScalpSetup(direction, bd(entry), bd(sl), bd(tp), rsi8, upper, lower, volumeRatio)
    }

    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return Double.NaN
        val alpha = 2.0 / (period + 1.0)
        var result = values.first()
        for (i in 1 until values.size) result += alpha * (values[i] - result)
        return result
    }

    /** Wilder-smoothed RSI, the standard RSI definition. */
    private fun rsi(values: List<Double>, period: Int): Double {
        if (values.size <= period) return 50.0
        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 1..period) {
            val change = values[i] - values[i - 1]
            if (change > 0) avgGain += change else avgLoss -= change
        }
        avgGain /= period
        avgLoss /= period
        for (i in period + 1 until values.size) {
            val change = values[i] - values[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }
        if (avgLoss == 0.0) return if (avgGain == 0.0) 50.0 else 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    private fun bd(value: Double): BigDecimal =
        BigDecimal.valueOf(value).setScale(12, RoundingMode.HALF_UP).stripTrailingZeros()
}
