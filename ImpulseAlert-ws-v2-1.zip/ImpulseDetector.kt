package com.impulse.alert

/**
 * Детектор ЗАРОДЖЕННЯ імпульсу (сигнал на вхід, а не констатація пройденого шляху).
 *
 * Тригер спрацьовує, коли ОДНОЧАСНО:
 *  1) за останні [moveWindowMs] (5–10 с) ціна рушила на [minMovePct]..[maxMovePct] %
 *     (верхня межа відсікає вже "пролетілі" рухи);
 *  2) є сплеск обсягу: оцінена швидкість торгів за ці секунди >= [volMultiplier] x
 *     від середньої швидкості монети за 24 год;
 *  3) (опційно) пробій мікро-діапазону: ціна вийшла за максимум/мінімум попередніх ~60 с.
 *
 * Один чистий сигнал на монету, далі пауза [cooldownMs]. Жодних рівнів 2%/3%.
 *
 * Обсяг береться з miniTicker (кумулятивний 24h quote volume, оновлення ~1 с),
 * тому це оцінка, а не точний tick-volume.
 */
class ImpulseDetector(
    private val moveWindowMs: Long = 8_000,
    private val rangeWindowMs: Long = 60_000,
    private val minMovePct: Double = 0.4,
    private val maxMovePct: Double = 0.8,
    private val volMultiplier: Double = 3.0,
    private val minQuoteVol24h: Double = 30_000_000.0,   // відсікаємо неліквід
    private val requireBreakout: Boolean = true,
    private val cooldownMs: Long = 5 * 60_000,
    private val warmupMs: Long = 15_000,
    private val onSignal: (symbol: String, direction: String, movePct: Double, volRatio: Double, price: Double) -> Unit
) {
    private class Tick(val t: Long, val p: Double, val q: Double)

    private val hist = HashMap<String, ArrayDeque<Tick>>()
    private val lastSignal = HashMap<String, Long>()

    @Synchronized
    fun clear() = hist.clear()

    @Synchronized
    fun onTick(symbol: String, price: Double, quoteVol24h: Double, now: Long) {
        if (price <= 0.0 || quoteVol24h <= 0.0) return
        val q = hist.getOrPut(symbol) { ArrayDeque() }
        q.addLast(Tick(now, price, quoteVol24h))
        while (q.isNotEmpty() && now - q.first().t > rangeWindowMs) q.removeFirst()

        if (quoteVol24h < minQuoteVol24h) return
        if (now - q.first().t < warmupMs) return                 // мало історії після (ре)конекту
        if (now - (lastSignal[symbol] ?: 0L) < cooldownMs) return

        val cut = now - moveWindowMs
        var recentMin = Double.MAX_VALUE
        var recentMax = 0.0
        var priorHi = 0.0
        var priorLo = Double.MAX_VALUE
        var recentCount = 0
        var ref: Tick? = null
        for (x in q) {
            if (x.t >= cut) {
                if (ref == null) ref = x
                recentCount++
                if (x.p < recentMin) recentMin = x.p
                if (x.p > recentMax) recentMax = x.p
            } else {
                if (x.p > priorHi) priorHi = x.p
                if (x.p < priorLo) priorLo = x.p
            }
        }
        if (ref == null || recentCount < 3 || priorHi == 0.0) return
        val dtSec = (now - ref.t) / 1000.0
        if (dtSec < 3.0) return

        // Оцінка сплеску обсягу відносно середньої 24h-швидкості
        val avgRate = quoteVol24h / 86_400.0
        val recentRate = maxOf(0.0, quoteVol24h - ref.q) / dtSec
        val volRatio = (recentRate + avgRate) / avgRate       // +avgRate: компенсація "вікна, що зсувається"
        if (volRatio < volMultiplier) return

        val up = (price - recentMin) / recentMin * 100.0
        val down = (recentMax - price) / recentMax * 100.0

        if (up in minMovePct..maxMovePct && (!requireBreakout || price > priorHi)) {
            fire(symbol, "LONG", up, volRatio, price, now)
        } else if (down in minMovePct..maxMovePct && (!requireBreakout || price < priorLo)) {
            fire(symbol, "SHORT", down, volRatio, price, now)
        }
    }

    private fun fire(symbol: String, dir: String, move: Double, vol: Double, price: Double, now: Long) {
        lastSignal[symbol] = now
        onSignal(symbol, dir, move, vol, price)
    }
}
