package com.impulse.alert

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Журнал сигналів. Для кожного сигналу фіксує ціну входу і далі 15 хвилин відстежує:
 *  - результат через 1, 5 і 15 хв (у % у бік сигналу, без комісій);
 *  - максимальний плюс (max_fav) і максимальну просадку (max_adv);
 *  - що було першим: ціль +TP% чи стоп -SL%  (outcome = TP / SL / NONE).
 * Завершені записи дописуються у signals.csv.
 */
class SignalJournal(private val file: File) {

    private class Pending(
        val symbol: String, val dir: String, val t0: Long,
        val entry: Double, val move: Double, val vol: Double
    ) {
        var r1: Double? = null
        var r5: Double? = null
        var r15: Double? = null
        var maxFav = 0.0
        var maxAdv = 0.0
        var outcome = ""
    }

    private val pending = HashMap<String, MutableList<Pending>>()

    @Synchronized
    fun add(symbol: String, dir: String, price: Double, move: Double, vol: Double, now: Long) {
        pending.getOrPut(symbol) { mutableListOf() }.add(Pending(symbol, dir, now, price, move, vol))
        tracking = pending.values.sumOf { it.size }
    }

    @Synchronized
    fun onTick(symbol: String, price: Double, now: Long) {
        val list = pending[symbol] ?: return
        val it = list.iterator()
        while (it.hasNext()) {
            val s = it.next()
            val r = if (s.dir == "LONG") (price - s.entry) / s.entry * 100.0
                    else (s.entry - price) / s.entry * 100.0
            if (r > s.maxFav) s.maxFav = r
            if (-r > s.maxAdv) s.maxAdv = -r
            if (s.outcome.isEmpty()) {
                if (s.maxFav >= TP) s.outcome = "TP"
                else if (s.maxAdv >= SL) s.outcome = "SL"
            }
            val age = now - s.t0
            if (age >= 60_000 && s.r1 == null) s.r1 = r
            if (age >= 300_000 && s.r5 == null) s.r5 = r
            if (age >= 900_000) {
                s.r15 = r
                write(s)
                it.remove()
            }
        }
        if (list.isEmpty()) pending.remove(symbol)
        tracking = pending.values.sumOf { it.size }
    }

    private fun write(s: Pending) {
        try {
            if (!file.exists()) {
                file.writeText("time,symbol,dir,entry,move_pct,vol_ratio,r1,r5,r15,max_fav,max_adv,outcome\n")
            }
            val f = { d: Double? -> if (d == null) "" else String.format(Locale.US, "%.3f", d) }
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(s.t0))
            file.appendText(
                "$time,${s.symbol},${s.dir},${s.entry},${f(s.move)},${f(s.vol)}," +
                "${f(s.r1)},${f(s.r5)},${f(s.r15)},${f(s.maxFav)},${f(s.maxAdv)}," +
                "${s.outcome.ifEmpty { "NONE" }}\n"
            )
        } catch (_: Exception) { }
    }

    companion object {
        const val TP = 2.0   // ціль, %
        const val SL = 1.0   // умовний стоп, %
        @Volatile var tracking = 0

        fun statsText(file: File): String {
            if (!file.exists()) return "Журнал порожній.\nСигнали з'являться тут через 15 хв після першого спрацювання."
            val rows = file.readLines().drop(1).mapNotNull { line ->
                val c = line.split(",")
                if (c.size < 12) null else try {
                    doubleArrayOf(
                        c[6].toDoubleOrNull() ?: Double.NaN,
                        c[7].toDoubleOrNull() ?: Double.NaN,
                        c[8].toDoubleOrNull() ?: Double.NaN,
                        c[9].toDouble(), c[10].toDouble()
                    ) to c[11]
                } catch (_: Exception) { null }
            }
            val n = rows.size
            if (n == 0) return "Журнал порожній."
            fun pct(x: Int) = String.format(Locale.US, "%.0f%%", x * 100.0 / n)
            fun avg(i: Int): String {
                val v = rows.map { it.first[i] }.filter { !it.isNaN() }
                return if (v.isEmpty()) "-" else String.format(Locale.US, "%+.2f%%", v.average())
            }
            val reach2 = rows.count { it.first[3] >= 2.0 }
            val reach3 = rows.count { it.first[3] >= 3.0 }
            val tp = rows.count { it.second == "TP" }
            val sl = rows.count { it.second == "SL" }
            val none = n - tp - sl
            val avgFav = String.format(Locale.US, "%.2f%%", rows.map { it.first[3] }.average())
            val avgAdv = String.format(Locale.US, "%.2f%%", rows.map { it.first[4] }.average())
            return "Завершених сигналів: $n\n" +
                "Дійшли до +2%: ${pct(reach2)} • до +3%: ${pct(reach3)}\n" +
                "Першим було +${TP.toInt()}%: ${pct(tp)}\n" +
                "Першим було -${SL.toInt()}% (стоп): ${pct(sl)}\n" +
                "Ні те, ні інше за 15 хв: ${pct(none)}\n" +
                "Середня зміна після входу:\n 1хв ${avg(0)} • 5хв ${avg(1)} • 15хв ${avg(2)}\n" +
                "Сер. макс. плюс $avgFav • макс. мінус $avgAdv\n" +
                "(без комісій і проковзування)"
        }
    }
}
